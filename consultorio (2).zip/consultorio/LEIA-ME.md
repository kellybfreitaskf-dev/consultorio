# Consultório: gestão para psicologia e neuropsicologia

Sistema web para consultório individual. Tem agenda, pacientes, prontuário, avaliação neuropsicológica com laudo, financeiro e lembretes por WhatsApp.

## O que o sistema faz

| Módulo | Recursos |
|---|---|
| **Agenda** | Visão de mês, semana, dia e lista. Para agendar, clique num horário. Para remarcar, arraste. Tem sessões recorrentes (semanal, quinzenal, mensal), presencial ou online com link, e status por cor (agendado, confirmado, realizado, falta, falta cobrada, cancelado). |
| **Pacientes** | Importação de planilha (Excel ou CSV) com prévia antes de confirmar. Cadastro completo com responsável (para crianças). Mostra última e próxima sessão e o valor em aberto. É possível inativar pacientes (alta). |
| **Prontuário** | Anamnese estruturada e evolução por sessão (com roteiro SOAP opcional). Imprime o prontuário completo (Res. CFP 01/2009). |
| **Documentos** | Declaração de comparecimento, atestado, encaminhamento e contrato terapêutico. O texto é editável antes de imprimir ou salvar em PDF. |
| **Avaliação neuropsicológica** | Registro dos testes por domínio cognitivo. Converte QI, escalar, T, Z e percentil, classifica automaticamente e gera o gráfico de perfil cognitivo. Também monta o **rascunho do laudo** na estrutura da Res. CFP 06/2019. |
| **Financeiro** | A cobrança é criada sozinha quando a sessão é marcada como realizada. Tem receitas e despesas (inclusive recorrentes), inadimplência, gráfico de 6 meses e **recibo com valor por extenso** (avulso ou mensal). |
| **Sessão com IA** | Grava a sessão presencial (microfone) ou online (microfone e áudio da aba do Meet). Também aceita um arquivo de áudio ou a transcrição colada. A IA devolve **4 partes**: evolução para o prontuário (editável antes de salvar), supervisão do caso, feedback sobre a sua atuação (pontos fortes, pontos a melhorar e um foco de treino) e o plano da próxima sessão. Tudo segue o **referencial teórico** de cada paciente (TCC, Esquema, DBT, ACT, Psicanálise e outros). Indicadores de risco geram um alerta em destaque. O plano aparece sozinho na página da próxima sessão. |
| **Cobranças por WhatsApp** | Lista quem tem valores em aberto. Com um clique, o WhatsApp abre com o resumo das sessões, o total e a sua chave Pix, já endereçado ao responsável financeiro, se houver. |
| **Supervisão e estudo de caso** | Monta o histórico do caso com iniciais no lugar do nome (anamnese, avaliações, evoluções) e um pedido pronto para colar no Claude: supervisão, estudo de caso, plano de tratamento ou evolução com a sua skill. Guarda os registros de supervisão. |
| **Ritmo da clínica** | Sessões realizadas, comparecimento, base de pacientes e valores no período escolhido, com estatísticas por dia da semana, mês, horário e forma de pagamento. |
| **Google Agenda** | Botão "Adicionar ao Google Agenda" em cada sessão e na série semanal inteira, mais a exportação da agenda num arquivo .ics. Com o sistema na internet, a agenda também pode ser assinada no Google por um endereço próprio e se atualiza sozinha. |
| **Respostas do WhatsApp** | Com a API oficial e o webhook configurados, a resposta "CONFIRMO" do paciente marca a sessão como confirmada sozinha. As demais respostas aparecem em Cobranças & lembretes e na tela inicial. |
| **Relatório mensal** | Sessões realizadas, faltas e cancelamentos de cada paciente no mês. Fica em Pacientes. |
| **Lembretes WhatsApp** | **Manual**: um clique abre o WhatsApp com a mensagem pronta. **Automático**: envio sozinho pela API oficial, X horas antes. Para menores de idade, a mensagem vai para o responsável. |
| **Segurança** | Login com senha, proteção contra tentativas repetidas e backup completo num clique. |

> O sistema **não inclui tabelas normativas** de testes, porque elas são protegidas e de uso restrito. Você digita o escore padronizado obtido no manual, e o sistema faz as conversões e a classificação.

---

## Opção 1: usar no seu computador (mais simples)

1. Instale o **Python** em https://www.python.org/downloads/. No Windows, marque a opção **"Add Python to PATH"** durante a instalação.
2. Abra a pasta do sistema e dê dois cliques em:
   - **Windows:** `iniciar-windows.bat`
   - **Mac/Linux:** `iniciar-mac-linux.sh`
3. O navegador abre em `http://localhost:5000`. Na primeira vez, crie seu usuário e senha.

Os dados ficam na pasta `dados/`. **Faça backup** pelo botão em Configurações. Neste modo, o sistema só funciona enquanto essa janela estiver aberta e só nesse computador.

## Opção 2: hospedar na internet (acesso pelo celular, de qualquer lugar)

Recomendado: **Railway** (cerca de US$ 5/mês). Passo a passo:

1. Crie uma conta em https://github.com e envie esta pasta como um repositório **privado** (botão "Add file → Upload files").
2. Crie uma conta em https://railway.com e clique em **New Project → Deploy from GitHub repo**. Escolha o repositório.
3. No serviço criado, abra **Settings → Volumes → Add Volume** com o caminho de montagem `/data`. É aqui que os dados ficam guardados.
4. Em **Variables**, adicione:
   - `SECRET_KEY` = uma frase longa e aleatória (ex.: 40 letras e números misturados)
   - `TZ_CONSULTORIO` = `America/Sao_Paulo`. Troque se o seu fuso for outro, por exemplo `America/Manaus`.
5. Em **Settings → Networking**, clique em **Generate Domain**. Esse é o endereço do seu sistema.
6. Acesse o endereço e crie seu usuário.

O `Dockerfile` também funciona em Render, Fly.io ou num servidor próprio. Em qualquer um deles, monte um disco persistente em `/data`.

---

## Sessão com IA: como configurar

São necessárias duas contas. Ambas são pagas por uso, com cartão de crédito internacional:

1. **Anthropic (Claude)**, que faz a análise. Crie a conta em https://console.anthropic.com, adicione créditos (Billing; US$ 5 já rendem dezenas de sessões) e gere uma chave em **API Keys**. A chave começa com `sk-ant-`.
2. **AssemblyAI**, que faz a transcrição com separação de quem fala. Crie a conta em https://www.assemblyai.com, adicione créditos e copie a chave do painel (**API Keys**).
3. No sistema, abra **Configurações → Inteligência artificial**, cole as duas chaves e escolha o referencial teórico padrão.
4. No cadastro de cada paciente, escolha a abordagem e registre a data do **termo de consentimento**. O modelo do termo está em Paciente → Documentos.

Custo aproximado por sessão de 50 min: US$ 0,15 a 0,30 de transcrição e US$ 0,20 a 0,40 de análise. O valor exato de cada análise aparece embaixo dela.

**Durante a sessão online:** abra o Meet numa aba do Chrome ou do Edge. Em outra aba, abra o atendimento e clique em **Gravar / enviar sessão → Online → Iniciar**. Na janela que aparece, escolha a **aba do Meet** e marque **"Compartilhar áudio da guia"**. Use fone de ouvido: assim o microfone capta só você e a aba capta o paciente.

**Privacidade:** o áudio nunca fica guardado no sistema. Ele é apagado logo depois da transcrição, e a cópia na AssemblyAI também é excluída. Antes de ir para o Claude, o nome do paciente e o do responsável são trocados por iniciais. Você pode apagar a transcrição de cada sessão, ou ativar a exclusão automática em Configurações.

## Lembretes automáticos pelo WhatsApp (opcional)

O **modo manual** funciona sem configurar nada: em **Lembretes**, clique em **Enviar** e o WhatsApp abre com a mensagem pronta.

Para o envio **100% automático**, é preciso usar a API oficial do WhatsApp (Meta). Ela é gratuita para configurar e cobra centavos por mensagem:

1. Em https://business.facebook.com, crie um **Gerenciador de Negócios**. Depois, em https://developers.facebook.com, crie um **App** do tipo *Business* e adicione o produto **WhatsApp**.
2. Cadastre o número do consultório. Use um número que **não** esteja em uso no app WhatsApp comum, ou migre o número.
3. Em **Modelos de mensagem**, crie um modelo chamado `lembrete_sessao`, categoria **Utilidade**, idioma **Português (BR)**, com este texto:
   > Olá, {{1}}! Lembrete da sua sessão na {{2}}, às {{3}}. Responda para confirmar ou remarcar.
4. Depois que o modelo for aprovado, copie o **Phone number ID** e gere um **token permanente** (Usuário do sistema → Gerar token, com a permissão `whatsapp_business_messaging`).
5. No sistema, abra **Configurações → Lembretes por WhatsApp**, cole os dados, escolha o modo **Automático** e use **Testar envio**.

O sistema verifica a cada 5 minutos e envia o lembrete para quem tem sessão dentro da antecedência configurada (padrão: 24 h).

---

## Cuidados legais (LGPD e CFP)

- Prontuários são **dados sensíveis de saúde**. Use uma senha forte e não compartilhe o acesso.
- Guarde o prontuário por **no mínimo 5 anos** (Res. CFP 01/2009). Prefira **inativar** o paciente em vez de excluir.
- Faça **backup semanal** e guarde o arquivo em local protegido. Não envie o backup por e-mail ou WhatsApp.
- Nos recibos, preencha seu **CPF** em Configurações. Ele é necessário para dedução no IR e para o lançamento no **Receita Saúde**.
- Para pacientes, informe no contrato como os dados são tratados. O modelo de contrato do sistema já inclui uma cláusula de LGPD.

## Para desenvolvedores

Python 3.10+ com Flask e SQLite. Os arquivos principais são `app.py` (rotas), `neuro.py` (escores), `whatsapp.py`, `util.py`, `schema.sql`, `templates/` e `static/`. As bibliotecas JavaScript (FullCalendar 6.1.15 e Chart.js 4.4.1) estão em `static/vendor/`, então o sistema não depende de CDN.
