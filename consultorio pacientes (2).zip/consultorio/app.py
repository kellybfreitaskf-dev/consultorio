"""Consultório — sistema de gestão para psicologia e neuropsicologia."""
import json
import os
import re
import sqlite3
import secrets
import threading
import time
import uuid
from datetime import datetime, date, timedelta
from functools import wraps
from zoneinfo import ZoneInfo

from flask import (Flask, g, render_template, request, redirect, url_for, session,
                   flash, jsonify, send_file, abort)
from werkzeug.security import generate_password_hash, check_password_hash

import markdown as md

import ia
import importar
import neuro
import whatsapp
from util import (parse_data, parse_dt, data_br, data_extenso, idade, moeda, numero,
                  valor_extenso, telefone_whatsapp, DIAS_SEMANA, MESES)

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("DATA_DIR", os.path.join(BASE, "dados"))
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "consultorio.db")
TZ = ZoneInfo(os.environ.get("TZ_CONSULTORIO", "America/Sao_Paulo"))

STATUS = {
    "agendado": ("Agendado", "#5b7fd6"),
    "confirmado": ("Confirmado", "#2f9e77"),
    "realizado": ("Realizado", "#6b6f80"),
    "falta": ("Falta", "#d9822b"),
    "falta_cobrada": ("Falta (cobrada)", "#c4572f"),
    "cancelado": ("Cancelado", "#b9bcc8"),
}
TIPOS_ATENDIMENTO = ["Psicoterapia", "Avaliação neuropsicológica", "Avaliação psicológica", "Anamnese",
                     "Devolutiva", "Orientação parental", "Reabilitação cognitiva", "Outro"]
FORMAS_PAGAMENTO = ["Pix", "Dinheiro", "Cartão de crédito", "Cartão de débito", "Transferência", "Boleto", "Convênio"]
CATEGORIAS_DESPESA = ["Aluguel", "Testes e materiais", "Supervisão", "Cursos", "Impostos", "Conselho (CRP)",
                      "Software", "Marketing", "Outros"]

DEFAULTS = {
    "profissional_nome": "",
    "profissional_crp": "",
    "profissional_cpf": "",
    "profissional_especialidade": "Psicóloga",
    "consultorio_nome": "",
    "consultorio_endereco": "",
    "consultorio_telefone": "",
    "cidade": "",
    "valor_sessao_padrao": "200",
    "duracao_padrao": "50",
    "msg_lembrete": ("Olá, {nome}! Passando para lembrar da sua sessão na {dia_semana}, {data}, às {hora}. "
                     "Por favor, responda CONFIRMO para confirmar ou me avise se precisar remarcar. "
                     "Até lá! {profissional}"),
    "lembrete_antecedencia_horas": "24",
    "whatsapp_modo": "manual",
    "wa_token": "",
    "wa_phone_id": "",
    "wa_template": "lembrete_sessao",
    "wa_template_lang": "pt_BR",
    "anthropic_api_key": "",
    "assemblyai_api_key": "",
    "abordagem_padrao": "TCC",
    "apagar_transcricao": "0",
}

app = Flask(__name__)


# ------------------------------------------------------------------ banco
def conectar():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def get_db():
    if "db" not in g:
        g.db = conectar()
    return g.db

@app.teardown_appcontext
def fechar_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def q(sql, args=(), one=False):
    rows = get_db().execute(sql, args).fetchall()
    return (rows[0] if rows else None) if one else rows

def x(sql, args=()):
    db = get_db()
    cur = db.execute(sql, args)
    db.commit()
    return cur.lastrowid

def init_db():
    con = conectar()
    with open(os.path.join(BASE, "schema.sql"), encoding="utf-8") as f:
        con.executescript(f.read())
    colunas = {r[1] for r in con.execute("PRAGMA table_info(pacientes)")}
    for col in ("abordagem", "consentimento_ia"):
        if col not in colunas:
            con.execute(f"ALTER TABLE pacientes ADD COLUMN {col} TEXT")
    # processamentos interrompidos por reinício do servidor
    con.execute("""UPDATE sessoes_ia SET status = 'erro', erro = 'Processamento interrompido (o servidor reiniciou). Tente novamente.'
                   WHERE status IN ('transcrevendo', 'analisando')""")
    con.commit()
    con.close()

def carregar_settings(con=None):
    con = con or get_db()
    s = dict(DEFAULTS)
    for r in con.execute("SELECT chave, valor FROM settings"):
        s[r["chave"]] = r["valor"]
    return s

def salvar_setting(chave, valor):
    x("INSERT INTO settings (chave, valor) VALUES (?, ?) ON CONFLICT(chave) DO UPDATE SET valor = excluded.valor",
      (chave, valor))

def secret_key():
    if os.environ.get("SECRET_KEY"):
        return os.environ["SECRET_KEY"]
    caminho = os.path.join(DATA_DIR, "secret.key")
    if not os.path.exists(caminho):
        with open(caminho, "w") as f:
            f.write(secrets.token_hex(32))
    with open(caminho) as f:
        return f.read().strip()

init_db()
app.secret_key = secret_key()
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=12),
    MAX_CONTENT_LENGTH=300 * 1024 * 1024,  # gravações de sessão
)

def agora():
    """Data/hora local do consultório, sem fuso (igual ao que é gravado na agenda)."""
    return datetime.now(TZ).replace(tzinfo=None)

def hoje():
    return agora().date()


# ------------------------------------------------------------------ templates
app.jinja_env.filters.update(
    data=data_br,
    moeda=moeda,
    idade=idade,
    extenso=data_extenso,
    hora=lambda s: s[11:16] if s else "",
    datahora=lambda s: (data_br(s) + " " + s[11:16]) if s else "",
    dia_semana=lambda s: DIAS_SEMANA[parse_data(s).weekday()] if parse_data(s) else "",
    num=lambda v: (f"{v:g}".replace(".", ",") if isinstance(v, (int, float)) else ""),
)

def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(24)
    return session["_csrf"]

@app.context_processor
def contexto():
    return {
        "csrf_token": csrf_token,
        "cfg": carregar_settings() if request.endpoint != "static" else {},
        "STATUS": STATUS,
        "ABORDAGENS": list(ia.ABORDAGENS),
        "hoje": hoje(),
    }


# ------------------------------------------------------------------ segurança
ABERTAS = {"login", "setup", "static"}

@app.before_request
def proteger():
    if request.endpoint in ABERTAS:
        pass
    else:
        if not q("SELECT 1 FROM usuarios LIMIT 1", one=True):
            return redirect(url_for("setup"))
        if not session.get("uid"):
            return redirect(url_for("login", next=request.path))
    if request.method == "POST":
        enviado = request.form.get("_csrf") or request.headers.get("X-CSRF")
        if not enviado or enviado != session.get("_csrf"):
            abort(400, "Sessão expirada. Volte, recarregue a página e tente novamente.")

@app.route("/configuracao-inicial", methods=["GET", "POST"])
def setup():
    if q("SELECT 1 FROM usuarios LIMIT 1", one=True):
        return redirect(url_for("login"))
    if request.method == "POST":
        f = request.form
        if len(f.get("senha", "")) < 8:
            flash("A senha precisa ter pelo menos 8 caracteres.", "erro")
        elif f.get("senha") != f.get("senha2"):
            flash("As senhas não conferem.", "erro")
        else:
            uid = x("INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)",
                    (f["nome"].strip(), f["email"].strip().lower(), generate_password_hash(f["senha"])))
            salvar_setting("profissional_nome", f["nome"].strip())
            salvar_setting("profissional_crp", f.get("crp", "").strip())
            session.clear()
            session["uid"] = uid
            session.permanent = True
            flash("Bem-vinda! Complete os dados do consultório em Configurações.", "ok")
            return redirect(url_for("config"))
    return render_template("setup.html")

_tentativas = {}

@app.route("/entrar", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        ip = request.headers.get("X-Forwarded-For", request.remote_addr or "")
        hist = [t for t in _tentativas.get(ip, []) if t > time.time() - 900]
        if len(hist) >= 10:
            flash("Muitas tentativas. Aguarde 15 minutos.", "erro")
            return render_template("login.html")
        u = q("SELECT * FROM usuarios WHERE email = ?", (request.form.get("email", "").strip().lower(),), one=True)
        if u and check_password_hash(u["senha_hash"], request.form.get("senha", "")):
            _tentativas.pop(ip, None)
            session.clear()
            session["uid"] = u["id"]
            session.permanent = True
            destino = request.args.get("next") or url_for("inicio")
            return redirect(destino if destino.startswith("/") else url_for("inicio"))
        hist.append(time.time())
        _tentativas[ip] = hist
        flash("E-mail ou senha incorretos.", "erro")
    return render_template("login.html")

@app.route("/sair")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ------------------------------------------------------------------ início
@app.route("/")
def inicio():
    d = hoje()
    atend_hoje = q("""SELECT a.*, p.nome, p.telefone FROM atendimentos a JOIN pacientes p ON p.id = a.paciente_id
                      WHERE date(a.inicio) = ? AND a.status != 'cancelado' ORDER BY a.inicio""", (d.isoformat(),))
    amanha = (d + timedelta(days=1)).isoformat()
    lembretes_pend = q("""SELECT COUNT(*) n FROM atendimentos WHERE date(inicio) = ? AND status IN ('agendado','confirmado')
                          AND lembrete_enviado_em IS NULL""", (amanha,), one=True)["n"]
    semana = q("""SELECT COUNT(*) n FROM atendimentos WHERE date(inicio) BETWEEN ? AND ? AND status != 'cancelado'""",
               (d.isoformat(), (d + timedelta(days=6)).isoformat()), one=True)["n"]
    mes = d.strftime("%Y-%m")
    recebido = q("SELECT COALESCE(SUM(valor),0) v FROM lancamentos WHERE tipo='receita' AND substr(pagamento,1,7)=?",
                 (mes,), one=True)["v"]
    a_receber = q("SELECT COALESCE(SUM(valor),0) v FROM lancamentos WHERE tipo='receita' AND pagamento IS NULL",
                  one=True)["v"]
    sem_evolucao = q("""SELECT a.*, p.nome FROM atendimentos a JOIN pacientes p ON p.id = a.paciente_id
                        WHERE a.status = 'realizado' AND date(a.inicio) >= ?
                        AND NOT EXISTS (SELECT 1 FROM evolucoes e WHERE e.atendimento_id = a.id)
                        ORDER BY a.inicio DESC LIMIT 6""", ((d - timedelta(days=30)).isoformat(),))
    passados_abertos = q("""SELECT a.*, p.nome FROM atendimentos a JOIN pacientes p ON p.id = a.paciente_id
                            WHERE a.status IN ('agendado','confirmado') AND a.inicio < ?
                            ORDER BY a.inicio DESC LIMIT 10""", (agora().strftime("%Y-%m-%dT%H:%M"),))
    aniversariantes = q("""SELECT id, nome, nascimento FROM pacientes WHERE ativo = 1 AND substr(nascimento,6,2) = ?
                           ORDER BY substr(nascimento,9,2)""", (d.strftime("%m"),))
    avaliacoes = q("""SELECT v.*, p.nome FROM avaliacoes v JOIN pacientes p ON p.id = v.paciente_id
                      WHERE v.status != 'Concluída' ORDER BY v.data_inicio""")
    return render_template("inicio.html", atend_hoje=atend_hoje, lembretes_pend=lembretes_pend, semana=semana,
                           recebido=recebido, a_receber=a_receber, sem_evolucao=sem_evolucao,
                           passados_abertos=passados_abertos, aniversariantes=aniversariantes, avaliacoes=avaliacoes)


# ------------------------------------------------------------------ pacientes
CAMPOS_PACIENTE = ["nome", "nascimento", "cpf", "sexo", "telefone", "email", "endereco", "escolaridade",
                   "profissao", "responsavel_nome", "responsavel_cpf", "responsavel_telefone", "convenio",
                   "valor_sessao", "observacoes", "abordagem", "consentimento_ia"]

@app.route("/pacientes")
def pacientes():
    busca = request.args.get("q", "").strip()
    inativos = request.args.get("inativos") == "1"
    sql = """SELECT p.*,
               (SELECT MAX(inicio) FROM atendimentos a WHERE a.paciente_id = p.id AND a.status='realizado') ultimo,
               (SELECT MIN(inicio) FROM atendimentos a WHERE a.paciente_id = p.id AND a.inicio >= ? AND a.status IN ('agendado','confirmado')) proximo,
               (SELECT COALESCE(SUM(valor),0) FROM lancamentos l WHERE l.paciente_id = p.id AND l.tipo='receita' AND l.pagamento IS NULL) devendo
             FROM pacientes p WHERE ativo = ?"""
    args = [agora().strftime("%Y-%m-%dT%H:%M"), 0 if inativos else 1]
    if busca:
        sql += " AND (p.nome LIKE ? OR p.cpf LIKE ? OR p.telefone LIKE ? OR p.responsavel_nome LIKE ?)"
        args += [f"%{busca}%"] * 4
    sql += " ORDER BY p.nome COLLATE NOCASE"
    return render_template("pacientes.html", pacientes=q(sql, args), busca=busca, inativos=inativos)

def dados_paciente_form():
    f = request.form
    d = {c: (f.get(c) or "").strip() or None for c in CAMPOS_PACIENTE}
    d["valor_sessao"] = numero(d["valor_sessao"])
    return d

@app.route("/pacientes/novo", methods=["GET", "POST"])
def paciente_novo():
    if request.method == "POST":
        d = dados_paciente_form()
        if not d["nome"]:
            flash("Informe o nome.", "erro")
        else:
            pid = x(f"INSERT INTO pacientes ({','.join(CAMPOS_PACIENTE)}) VALUES ({','.join('?' * len(CAMPOS_PACIENTE))})",
                    [d[c] for c in CAMPOS_PACIENTE])
            flash("Paciente cadastrado.", "ok")
            return redirect(url_for("paciente", pid=pid))
    return render_template("paciente_form.html", p={}, )

@app.route("/pacientes/<int:pid>/editar", methods=["GET", "POST"])
def paciente_editar(pid):
    p = q("SELECT * FROM pacientes WHERE id = ?", (pid,), one=True) or abort(404)
    if request.method == "POST":
        d = dados_paciente_form()
        x(f"UPDATE pacientes SET {','.join(c + '=?' for c in CAMPOS_PACIENTE)} WHERE id = ?",
          [d[c] for c in CAMPOS_PACIENTE] + [pid])
        flash("Dados atualizados.", "ok")
        return redirect(url_for("paciente", pid=pid))
    return render_template("paciente_form.html", p=p)

@app.route("/pacientes/<int:pid>/ativo", methods=["POST"])
def paciente_ativo(pid):
    x("UPDATE pacientes SET ativo = CASE ativo WHEN 1 THEN 0 ELSE 1 END WHERE id = ?", (pid,))
    flash("Situação do paciente alterada.", "ok")
    return redirect(url_for("paciente", pid=pid))

@app.route("/pacientes/<int:pid>/excluir", methods=["POST"])
def paciente_excluir(pid):
    p = q("SELECT * FROM pacientes WHERE id = ?", (pid,), one=True) or abort(404)
    if request.form.get("confirmacao", "").strip().lower() != p["nome"].strip().lower():
        flash("Para excluir, digite o nome completo do paciente exatamente como cadastrado.", "erro")
        return redirect(url_for("paciente", pid=pid))
    x("DELETE FROM pacientes WHERE id = ?", (pid,))
    flash("Paciente e todo o prontuário foram excluídos.", "ok")
    return redirect(url_for("pacientes"))

@app.route("/pacientes/<int:pid>")
def paciente(pid):
    p = q("SELECT * FROM pacientes WHERE id = ?", (pid,), one=True) or abort(404)
    atendimentos = q("SELECT * FROM atendimentos WHERE paciente_id = ? ORDER BY inicio DESC", (pid,))
    evolucoes = q("SELECT * FROM evolucoes WHERE paciente_id = ? ORDER BY data DESC, id DESC", (pid,))
    avaliacoes = q("SELECT * FROM avaliacoes WHERE paciente_id = ? ORDER BY data_inicio DESC", (pid,))
    lancamentos = q("SELECT * FROM lancamentos WHERE paciente_id = ? ORDER BY vencimento DESC", (pid,))
    anamnese = q("SELECT * FROM anamneses WHERE paciente_id = ?", (pid,), one=True)
    devendo = sum(l["valor"] for l in lancamentos if l["tipo"] == "receita" and not l["pagamento"])
    contagem = {k: sum(1 for a in atendimentos if a["status"] == k) for k in STATUS}
    return render_template("paciente.html", p=p, atendimentos=atendimentos, evolucoes=evolucoes,
                           avaliacoes=avaliacoes, lancamentos=lancamentos, anamnese=anamnese,
                           devendo=devendo, contagem=contagem, agora=agora().strftime("%Y-%m-%dT%H:%M"),
                           wa=whatsapp.link_wa(p["telefone"] or p["responsavel_telefone"], ""))


# ------------------------------------------------------------------ agenda
@app.route("/agenda")
def agenda():
    return render_template("agenda.html")

@app.route("/api/eventos")
def api_eventos():
    ini, fim = request.args.get("start", "")[:10], request.args.get("end", "")[:10]
    rows = q("""SELECT a.*, p.nome FROM atendimentos a JOIN pacientes p ON p.id = a.paciente_id
                WHERE date(a.inicio) >= ? AND date(a.inicio) < ?""", (ini, fim))
    eventos = []
    for a in rows:
        dt = parse_dt(a["inicio"])
        cor = STATUS.get(a["status"], ("", "#888"))[1]
        eventos.append({
            "id": a["id"],
            "title": a["nome"] + (" · online" if a["modalidade"] == "Online" else ""),
            "start": a["inicio"],
            "end": (dt + timedelta(minutes=a["duracao_min"] or 50)).strftime("%Y-%m-%dT%H:%M"),
            "backgroundColor": cor, "borderColor": cor,
            "classNames": ["ev-" + a["status"]],
            "extendedProps": {"tipo": a["tipo"], "status": STATUS.get(a["status"], ("",))[0]},
            "url": url_for("atendimento", aid=a["id"]),
        })
    return jsonify(eventos)

@app.route("/api/atendimentos/<int:aid>/mover", methods=["POST"])
def api_mover(aid):
    dados = request.get_json(force=True)
    ini, fim = parse_dt(dados.get("inicio")), parse_dt(dados.get("fim"))
    if not ini:
        return jsonify(ok=False), 400
    dur = int((fim - ini).total_seconds() // 60) if fim else None
    if dur:
        x("UPDATE atendimentos SET inicio = ?, duracao_min = ?, lembrete_enviado_em = NULL WHERE id = ?",
          (ini.strftime("%Y-%m-%dT%H:%M"), dur, aid))
    else:
        x("UPDATE atendimentos SET inicio = ?, lembrete_enviado_em = NULL WHERE id = ?",
          (ini.strftime("%Y-%m-%dT%H:%M"), aid))
    return jsonify(ok=True)

def sincronizar_financeiro(aid):
    """Cria/remove a cobrança conforme o status do atendimento."""
    a = q("SELECT a.*, p.nome FROM atendimentos a JOIN pacientes p ON p.id = a.paciente_id WHERE a.id = ?",
          (aid,), one=True)
    if not a:
        return
    lanc = q("SELECT * FROM lancamentos WHERE atendimento_id = ?", (aid,), one=True)
    cobrar = a["status"] in ("realizado", "falta_cobrada") and (a["valor"] or 0) > 0
    if cobrar and not lanc:
        desc = f'{a["tipo"] or "Sessão"} — {data_br(a["inicio"])}' + (" (falta)" if a["status"] == "falta_cobrada" else "")
        x("""INSERT INTO lancamentos (tipo, descricao, categoria, valor, vencimento, paciente_id, atendimento_id)
             VALUES ('receita', ?, 'Atendimento', ?, ?, ?, ?)""",
          (desc, a["valor"], a["inicio"][:10], a["paciente_id"], aid))
    elif cobrar and lanc and not lanc["pagamento"]:
        x("UPDATE lancamentos SET valor = ? WHERE id = ?", (a["valor"], lanc["id"]))
    elif not cobrar and lanc and not lanc["pagamento"]:
        x("DELETE FROM lancamentos WHERE id = ?", (lanc["id"],))

def form_atendimento():
    f = request.form
    data, horario = f.get("data"), f.get("hora")
    return {
        "paciente_id": int(f["paciente_id"]),
        "inicio": f"{data}T{horario}",
        "duracao_min": int(f.get("duracao_min") or 50),
        "tipo": f.get("tipo"),
        "modalidade": f.get("modalidade") or "Presencial",
        "link_online": (f.get("link_online") or "").strip() or None,
        "status": f.get("status") or "agendado",
        "valor": numero(f.get("valor")),
        "observacoes": (f.get("observacoes") or "").strip() or None,
    }

@app.route("/atendimentos/novo", methods=["GET", "POST"])
def atendimento_novo():
    pacs = q("SELECT id, nome, valor_sessao FROM pacientes WHERE ativo = 1 ORDER BY nome COLLATE NOCASE")
    if request.method == "POST":
        d = form_atendimento()
        repetir = max(1, min(int(request.form.get("repetir") or 1), 104))
        intervalo = int(request.form.get("intervalo") or 7)
        serie = uuid.uuid4().hex[:12] if repetir > 1 else None
        base = parse_dt(d["inicio"])
        if not base:
            flash("Data ou hora inválida.", "erro")
            return redirect(request.url)
        primeiro = None
        for i in range(repetir):
            d2 = dict(d, inicio=(base + timedelta(days=intervalo * i)).strftime("%Y-%m-%dT%H:%M"), serie_id=serie)
            aid = x(f"INSERT INTO atendimentos ({','.join(d2)}) VALUES ({','.join('?' * len(d2))})", list(d2.values()))
            sincronizar_financeiro(aid)
            primeiro = primeiro or aid
        flash(f"{repetir} atendimento(s) agendado(s)." if repetir > 1 else "Atendimento agendado.", "ok")
        return redirect(request.args.get("voltar") or url_for("agenda"))
    ini = request.args.get("inicio", "")
    a = {
        "paciente_id": request.args.get("paciente_id", type=int),
        "inicio": ini[:16] if len(ini) >= 16 else (ini[:10] + "T09:00" if ini else ""),
        "duracao_min": int(carregar_settings()["duracao_padrao"] or 50),
        "status": "agendado", "modalidade": "Presencial", "tipo": "Psicoterapia",
    }
    return render_template("atendimento_form.html", a=a, pacientes=pacs, novo=True,
                           TIPOS=TIPOS_ATENDIMENTO)

@app.route("/atendimentos/<int:aid>")
def atendimento(aid):
    a = q("SELECT * FROM atendimentos WHERE id = ?", (aid,), one=True) or abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (a["paciente_id"],), one=True)
    evol = q("SELECT * FROM evolucoes WHERE atendimento_id = ?", (aid,), one=True)
    lanc = q("SELECT * FROM lancamentos WHERE atendimento_id = ?", (aid,), one=True)
    s = carregar_settings()
    msg = whatsapp.montar_mensagem(s["msg_lembrete"], whatsapp.campos_mensagem(a, p, s))
    serie_futura = 0
    if a["serie_id"]:
        serie_futura = q("SELECT COUNT(*) n FROM atendimentos WHERE serie_id = ? AND inicio > ?",
                         (a["serie_id"], a["inicio"]), one=True)["n"]
    sessoes = q("SELECT * FROM sessoes_ia WHERE atendimento_id = ? ORDER BY id DESC", (aid,))
    plano = q("""SELECT r.*, a2.inicio FROM sessoes_ia r LEFT JOIN atendimentos a2 ON a2.id = r.atendimento_id
                 WHERE r.paciente_id = ? AND r.status = 'pronto' AND (a2.inicio IS NULL OR a2.inicio < ?)
                 ORDER BY a2.inicio DESC, r.id DESC LIMIT 1""", (p["id"], a["inicio"]), one=True)
    return render_template("atendimento.html", a=a, p=p, evol=evol, lanc=lanc,
                           wa=whatsapp.link_wa(telefone_lembrete(p), msg), serie_futura=serie_futura,
                           sessoes=sessoes, plano=plano)

@app.route("/atendimentos/<int:aid>/editar", methods=["GET", "POST"])
def atendimento_editar(aid):
    a = q("SELECT * FROM atendimentos WHERE id = ?", (aid,), one=True) or abort(404)
    if request.method == "POST":
        d = form_atendimento()
        if d["inicio"] != a["inicio"]:
            d["lembrete_enviado_em"] = None
        x(f"UPDATE atendimentos SET {','.join(k + '=?' for k in d)} WHERE id = ?", list(d.values()) + [aid])
        if request.form.get("aplicar_serie") and a["serie_id"]:
            # mesma alteração de horário/duração/valor para os próximos da série
            nova = parse_dt(d["inicio"])
            for b in q("SELECT * FROM atendimentos WHERE serie_id = ? AND inicio > ? AND id != ?",
                       (a["serie_id"], a["inicio"], aid)):
                bd = parse_dt(b["inicio"]).replace(hour=nova.hour, minute=nova.minute)
                bd = bd + timedelta(days=(nova.weekday() - parse_dt(a["inicio"]).weekday()))
                x("""UPDATE atendimentos SET inicio=?, duracao_min=?, valor=?, tipo=?, modalidade=?, link_online=?,
                     lembrete_enviado_em=NULL WHERE id=?""",
                  (bd.strftime("%Y-%m-%dT%H:%M"), d["duracao_min"], d["valor"], d["tipo"], d["modalidade"],
                   d["link_online"], b["id"]))
        sincronizar_financeiro(aid)
        flash("Atendimento atualizado.", "ok")
        return redirect(url_for("atendimento", aid=aid))
    pacs = q("SELECT id, nome, valor_sessao FROM pacientes ORDER BY nome COLLATE NOCASE")
    return render_template("atendimento_form.html", a=a, pacientes=pacs, novo=False, TIPOS=TIPOS_ATENDIMENTO)

@app.route("/atendimentos/<int:aid>/status", methods=["POST"])
def atendimento_status(aid):
    st = request.form.get("status")
    if st not in STATUS:
        abort(400)
    x("UPDATE atendimentos SET status = ? WHERE id = ?", (st, aid))
    sincronizar_financeiro(aid)
    flash(f"Status alterado para {STATUS[st][0]}.", "ok")
    if st == "realizado" and request.form.get("evoluir"):
        return redirect(url_for("evolucao_nova", pid=q("SELECT paciente_id FROM atendimentos WHERE id=?", (aid,), one=True)[0], atendimento_id=aid))
    return redirect(request.form.get("voltar") or url_for("atendimento", aid=aid))

@app.route("/atendimentos/<int:aid>/excluir", methods=["POST"])
def atendimento_excluir(aid):
    a = q("SELECT * FROM atendimentos WHERE id = ?", (aid,), one=True) or abort(404)
    x("DELETE FROM lancamentos WHERE atendimento_id = ? AND pagamento IS NULL", (aid,))
    n = 1
    if request.form.get("serie") and a["serie_id"]:
        futuros = q("SELECT id FROM atendimentos WHERE serie_id = ? AND inicio > ?", (a["serie_id"], a["inicio"]))
        for b in futuros:
            x("DELETE FROM lancamentos WHERE atendimento_id = ? AND pagamento IS NULL", (b["id"],))
            x("DELETE FROM atendimentos WHERE id = ?", (b["id"],))
        n += len(futuros)
    x("DELETE FROM atendimentos WHERE id = ?", (aid,))
    flash(f"{n} atendimento(s) excluído(s).", "ok")
    return redirect(url_for("agenda"))


# ------------------------------------------------------------------ prontuário
@app.route("/pacientes/<int:pid>/evolucoes/nova", methods=["GET", "POST"])
def evolucao_nova(pid):
    p = q("SELECT * FROM pacientes WHERE id = ?", (pid,), one=True) or abort(404)
    aid = request.values.get("atendimento_id", type=int)
    a = q("SELECT * FROM atendimentos WHERE id = ?", (aid,), one=True) if aid else None
    if request.method == "POST":
        texto = request.form.get("texto", "").strip()
        if not texto:
            flash("Escreva a evolução.", "erro")
        else:
            x("INSERT INTO evolucoes (paciente_id, atendimento_id, data, texto) VALUES (?, ?, ?, ?)",
              (pid, aid, request.form.get("data") or hoje().isoformat(), texto))
            flash("Evolução registrada.", "ok")
            return redirect(url_for("paciente", pid=pid) + "#evolucoes")
    ultima = q("SELECT * FROM evolucoes WHERE paciente_id = ? ORDER BY data DESC, id DESC LIMIT 1", (pid,), one=True)
    return render_template("evolucao_form.html", p=p, a=a, e={"data": (a["inicio"][:10] if a else hoje().isoformat())},
                           ultima=ultima)

@app.route("/evolucoes/<int:eid>/editar", methods=["GET", "POST"])
def evolucao_editar(eid):
    e = q("SELECT * FROM evolucoes WHERE id = ?", (eid,), one=True) or abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (e["paciente_id"],), one=True)
    if request.method == "POST":
        x("UPDATE evolucoes SET data = ?, texto = ?, atualizado_em = ? WHERE id = ?",
          (request.form.get("data"), request.form.get("texto", "").strip(), agora().isoformat(timespec="minutes"), eid))
        flash("Evolução atualizada.", "ok")
        return redirect(url_for("paciente", pid=p["id"]) + "#evolucoes")
    return render_template("evolucao_form.html", p=p, a=None, e=e, ultima=None)

@app.route("/evolucoes/<int:eid>/excluir", methods=["POST"])
def evolucao_excluir(eid):
    e = q("SELECT * FROM evolucoes WHERE id = ?", (eid,), one=True) or abort(404)
    x("DELETE FROM evolucoes WHERE id = ?", (eid,))
    flash("Evolução excluída.", "ok")
    return redirect(url_for("paciente", pid=e["paciente_id"]) + "#evolucoes")

CAMPOS_ANAMNESE = [
    ("queixa", "Queixa principal e motivo da procura"),
    ("historico", "Histórico da queixa"),
    ("desenvolvimento", "Gestação, parto e desenvolvimento neuropsicomotor"),
    ("saude", "Saúde geral, sono, alimentação, internações, exames"),
    ("medicacoes", "Medicações em uso e tratamentos anteriores"),
    ("familia", "Dinâmica e histórico familiar"),
    ("escolar", "Histórico escolar / profissional"),
    ("social", "Vida social, lazer e rotina"),
    ("outros", "Outras observações"),
]

@app.route("/pacientes/<int:pid>/anamnese", methods=["GET", "POST"])
def anamnese(pid):
    p = q("SELECT * FROM pacientes WHERE id = ?", (pid,), one=True) or abort(404)
    if request.method == "POST":
        campos = [c for c, _ in CAMPOS_ANAMNESE]
        vals = [request.form.get(c, "").strip() or None for c in campos]
        x(f"""INSERT INTO anamneses (paciente_id, {','.join(campos)}, atualizado_em) VALUES (?, {','.join('?' * len(campos))}, ?)
              ON CONFLICT(paciente_id) DO UPDATE SET {','.join(c + '=excluded.' + c for c in campos)},
              atualizado_em = excluded.atualizado_em""",
          [pid] + vals + [agora().isoformat(timespec="minutes")])
        flash("Anamnese salva.", "ok")
        return redirect(url_for("paciente", pid=pid))
    an = q("SELECT * FROM anamneses WHERE paciente_id = ?", (pid,), one=True) or {}
    return render_template("anamnese.html", p=p, an=an, campos=CAMPOS_ANAMNESE)

@app.route("/pacientes/<int:pid>/prontuario")
def prontuario(pid):
    p = q("SELECT * FROM pacientes WHERE id = ?", (pid,), one=True) or abort(404)
    return render_template(
        "prontuario.html", p=p,
        an=q("SELECT * FROM anamneses WHERE paciente_id = ?", (pid,), one=True),
        campos=CAMPOS_ANAMNESE,
        evolucoes=q("SELECT * FROM evolucoes WHERE paciente_id = ? ORDER BY data, id", (pid,)),
        atendimentos=q("SELECT * FROM atendimentos WHERE paciente_id = ? ORDER BY inicio", (pid,)),
        avaliacoes=q("SELECT * FROM avaliacoes WHERE paciente_id = ? ORDER BY data_inicio", (pid,)),
    )

@app.route("/pacientes/<int:pid>/documento")
def documento(pid):
    p = q("SELECT * FROM pacientes WHERE id = ?", (pid,), one=True) or abort(404)
    tipo = request.args.get("tipo", "declaracao")
    return render_template("documento.html", p=p, tipo=tipo, args=request.args)


# ------------------------------------------------------------------ avaliação neuropsicológica
CAMPOS_AVALIACAO = ["titulo", "data_inicio", "data_fim", "solicitante", "motivo", "hipoteses", "status",
                    "conclusao", "recomendacoes"]

@app.route("/pacientes/<int:pid>/avaliacoes/nova", methods=["GET", "POST"])
def avaliacao_nova(pid):
    p = q("SELECT * FROM pacientes WHERE id = ?", (pid,), one=True) or abort(404)
    if request.method == "POST":
        vals = [request.form.get(c, "").strip() or None for c in CAMPOS_AVALIACAO]
        vid = x(f"INSERT INTO avaliacoes (paciente_id, {','.join(CAMPOS_AVALIACAO)}) VALUES (?, {','.join('?' * len(CAMPOS_AVALIACAO))})",
                [pid] + vals)
        flash("Avaliação criada. Agora registre os testes aplicados.", "ok")
        return redirect(url_for("avaliacao", vid=vid))
    v = {"titulo": "Avaliação neuropsicológica", "data_inicio": hoje().isoformat(), "status": "Em andamento"}
    return render_template("avaliacao_form.html", p=p, v=v)

@app.route("/avaliacoes/<int:vid>/editar", methods=["GET", "POST"])
def avaliacao_editar(vid):
    v = q("SELECT * FROM avaliacoes WHERE id = ?", (vid,), one=True) or abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (v["paciente_id"],), one=True)
    if request.method == "POST":
        vals = [request.form.get(c, "").strip() or None for c in CAMPOS_AVALIACAO]
        x(f"UPDATE avaliacoes SET {','.join(c + '=?' for c in CAMPOS_AVALIACAO)} WHERE id = ?", vals + [vid])
        flash("Avaliação atualizada.", "ok")
        return redirect(url_for("avaliacao", vid=vid))
    return render_template("avaliacao_form.html", p=p, v=v)

@app.route("/avaliacoes/<int:vid>/excluir", methods=["POST"])
def avaliacao_excluir(vid):
    v = q("SELECT * FROM avaliacoes WHERE id = ?", (vid,), one=True) or abort(404)
    x("DELETE FROM avaliacoes WHERE id = ?", (vid,))
    flash("Avaliação excluída.", "ok")
    return redirect(url_for("paciente", pid=v["paciente_id"]))

def testes_analisados(vid):
    out = []
    for t in q("SELECT * FROM testes WHERE avaliacao_id = ? ORDER BY dominio, nome, subteste", (vid,)):
        d = dict(t)
        d.update(neuro.analisar_teste(t))
        out.append(d)
    return out

@app.route("/avaliacoes/<int:vid>")
def avaliacao(vid):
    v = q("SELECT * FROM avaliacoes WHERE id = ?", (vid,), one=True) or abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (v["paciente_id"],), one=True)
    testes = testes_analisados(vid)
    por_dominio = {}
    for t in testes:
        por_dominio.setdefault(t["dominio"] or "Outro", []).append(t)
    grafico = [{"rotulo": t["nome"] + (f' — {t["subteste"]}' if t["subteste"] else ""), "z": t["z_funcional"],
                "dominio": t["dominio"] or "Outro"} for t in testes if t["z_funcional"] is not None]
    sessoes = q("""SELECT * FROM atendimentos WHERE paciente_id = ? AND date(inicio) >= ?
                   AND (? IS NULL OR date(inicio) <= ?) ORDER BY inicio""",
                (p["id"], v["data_inicio"] or "0000", v["data_fim"], v["data_fim"]))
    return render_template("avaliacao.html", v=v, p=p, testes=testes, por_dominio=por_dominio, grafico=grafico,
                           sessoes=sessoes, TIPOS_ESCORE=neuro.TIPOS_ESCORE, DOMINIOS=neuro.DOMINIOS,
                           SUGERIDOS=neuro.TESTES_SUGERIDOS, FAIXAS=neuro.FAIXAS)

@app.route("/avaliacoes/<int:vid>/testes", methods=["POST"])
def teste_novo(vid):
    q("SELECT 1 FROM avaliacoes WHERE id = ?", (vid,), one=True) or abort(404)
    f = request.form
    tid = f.get("teste_id", type=int)
    vals = ((f.get("nome") or "").strip(), (f.get("subteste") or "").strip() or None, f.get("dominio"),
            f.get("data") or None, (f.get("escore_bruto") or "").strip() or None, f.get("tipo_escore"),
            numero(f.get("escore")), 1 if f.get("inverso") else 0, (f.get("observacoes") or "").strip() or None)
    if not vals[0]:
        flash("Informe o nome do teste.", "erro")
    elif tid:
        x("""UPDATE testes SET nome=?, subteste=?, dominio=?, data=?, escore_bruto=?, tipo_escore=?, escore=?,
             inverso=?, observacoes=? WHERE id=? AND avaliacao_id=?""", vals + (tid, vid))
        flash("Resultado atualizado.", "ok")
    else:
        x("""INSERT INTO testes (avaliacao_id, nome, subteste, dominio, data, escore_bruto, tipo_escore, escore,
             inverso, observacoes) VALUES (?,?,?,?,?,?,?,?,?,?)""", (vid,) + vals)
        flash("Resultado adicionado.", "ok")
    return redirect(url_for("avaliacao", vid=vid) + "#testes")

@app.route("/testes/<int:tid>/excluir", methods=["POST"])
def teste_excluir(tid):
    t = q("SELECT * FROM testes WHERE id = ?", (tid,), one=True) or abort(404)
    x("DELETE FROM testes WHERE id = ?", (tid,))
    return redirect(url_for("avaliacao", vid=t["avaliacao_id"]) + "#testes")

def rascunho_laudo(v, p):
    s = carregar_settings()
    an = q("SELECT * FROM anamneses WHERE paciente_id = ?", (p["id"],), one=True)
    testes = testes_analisados(v["id"])
    sessoes = q("""SELECT * FROM atendimentos WHERE paciente_id = ? AND status = 'realizado' AND date(inicio) >= ?
                   AND (? IS NULL OR date(inicio) <= ?) ORDER BY inicio""",
                (p["id"], v["data_inicio"] or "0000", v["data_fim"], v["data_fim"]))
    instrumentos = sorted({t["nome"] for t in testes})
    idd = idade(p["nascimento"])
    L = []
    L.append("LAUDO NEUROPSICOLÓGICO\n")
    L.append("1. IDENTIFICAÇÃO")
    L.append(f"Autora: {s['profissional_nome']} — {s['profissional_especialidade']} — CRP {s['profissional_crp']}")
    L.append(f"Interessado/solicitante: {v['solicitante'] or '[informar]'}")
    L.append(f"Avaliado(a): {p['nome']}" + (f", {idd} anos" if idd is not None else "")
             + (f", nascido(a) em {data_br(p['nascimento'])}" if p["nascimento"] else ""))
    if p["escolaridade"]:
        L.append(f"Escolaridade: {p['escolaridade']}")
    if p["responsavel_nome"]:
        L.append(f"Responsável: {p['responsavel_nome']}")
    L.append(f"Finalidade: {v['motivo'] or '[descrever a finalidade da avaliação]'}\n")
    L.append("2. DESCRIÇÃO DA DEMANDA")
    L.append((an["queixa"] if an and an["queixa"] else "[Descrever a demanda, o motivo do encaminhamento e as queixas apresentadas.]"))
    if v["hipoteses"]:
        L.append(f"Hipóteses iniciais: {v['hipoteses']}")
    L.append("")
    L.append("3. PROCEDIMENTO")
    periodo = data_br(v["data_inicio"]) + (f" a {data_br(v['data_fim'])}" if v["data_fim"] else "")
    L.append(f"A avaliação foi realizada no período de {periodo}, em {len(sessoes) or '[n]'} sessões, "
             "incluindo entrevista de anamnese, aplicação de instrumentos padronizados, observação clínica e devolutiva.")
    L.append("Instrumentos utilizados: " + ("; ".join(instrumentos) if instrumentos else "[listar]") + ".\n")
    L.append("4. ANÁLISE")
    if an:
        if an["historico"]:
            L.append("Histórico: " + an["historico"])
        if an["desenvolvimento"]:
            L.append("Desenvolvimento: " + an["desenvolvimento"])
        if an["escolar"]:
            L.append("Histórico escolar/profissional: " + an["escolar"])
        L.append("")
    dominios = {}
    for t in testes:
        dominios.setdefault(t["dominio"] or "Outro", []).append(t)
    for dom, lista in dominios.items():
        L.append(f"{dom}:")
        for t in lista:
            nome = t["nome"] + (f" ({t['subteste']})" if t["subteste"] else "")
            if t["escore"] is not None:
                L.append(f"  • {nome}: escore {t['escore']:g} ({t['tipo_escore']}), percentil ≈ {t['percentil']:g} — "
                         f"classificação {t['classificacao'].lower()}.")
            else:
                L.append(f"  • {nome}: {t['observacoes'] or 'resultado qualitativo'}")
        L.append("  [Interpretação qualitativa integrando os resultados deste domínio.]\n")
    L.append("5. CONCLUSÃO")
    L.append((v["conclusao"] or "[Síntese integrando história, observação e resultados; hipótese diagnóstica, se houver, com CID.]") + "\n")
    L.append("Recomendações e encaminhamentos:")
    L.append((v["recomendacoes"] or "[Recomendações e encaminhamentos.]") + "\n")
    L.append("Este documento foi elaborado conforme a Resolução CFP nº 06/2019, tem caráter sigiloso e "
             "destina-se exclusivamente à finalidade descrita, não devendo ser utilizado para outros fins.\n")
    L.append("6. REFERÊNCIAS")
    L.append("[Referências dos manuais dos instrumentos e literatura citada.]\n")
    L.append(f"{s['cidade'] or '[Cidade]'}, {data_extenso(hoje())}.")
    return "\n".join(L)

@app.route("/avaliacoes/<int:vid>/laudo", methods=["GET", "POST"])
def laudo(vid):
    v = q("SELECT * FROM avaliacoes WHERE id = ?", (vid,), one=True) or abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (v["paciente_id"],), one=True)
    if request.method == "POST":
        if request.form.get("acao") == "gerar":
            x("UPDATE avaliacoes SET laudo = ? WHERE id = ?", (rascunho_laudo(v, p), vid))
            flash("Rascunho do laudo gerado a partir dos dados da avaliação. Revise e complete os trechos entre colchetes.", "ok")
        else:
            x("UPDATE avaliacoes SET laudo = ? WHERE id = ?", (request.form.get("laudo", ""), vid))
            flash("Laudo salvo.", "ok")
        return redirect(url_for("laudo", vid=vid))
    return render_template("laudo.html", v=v, p=p)

@app.route("/avaliacoes/<int:vid>/laudo/imprimir")
def laudo_imprimir(vid):
    v = q("SELECT * FROM avaliacoes WHERE id = ?", (vid,), one=True) or abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (v["paciente_id"],), one=True)
    testes = testes_analisados(vid)
    grafico = [{"rotulo": t["nome"] + (f' — {t["subteste"]}' if t["subteste"] else ""), "z": t["z_funcional"],
                "dominio": t["dominio"] or "Outro"} for t in testes if t["z_funcional"] is not None]
    return render_template("laudo_print.html", v=v, p=p, grafico=grafico,
                           incluir_grafico=request.args.get("grafico") == "1")


# ------------------------------------------------------------------ financeiro
@app.route("/financeiro")
def financeiro():
    mes = request.args.get("mes") or hoje().strftime("%Y-%m")
    try:
        ref = datetime.strptime(mes, "%Y-%m").date()
    except ValueError:
        ref = hoje().replace(day=1)
        mes = ref.strftime("%Y-%m")
    filtro = request.args.get("filtro", "todos")
    sql = """SELECT l.*, p.nome FROM lancamentos l LEFT JOIN pacientes p ON p.id = l.paciente_id
             WHERE (substr(l.vencimento,1,7) = ? OR substr(l.pagamento,1,7) = ?)"""
    if filtro == "pendentes":
        sql += " AND l.pagamento IS NULL"
    elif filtro == "pagos":
        sql += " AND l.pagamento IS NOT NULL"
    elif filtro in ("receita", "despesa"):
        sql += f" AND l.tipo = '{filtro}'"
    lancs = q(sql + " ORDER BY l.vencimento, l.id", (mes, mes))

    def soma(where, args):
        return q(f"SELECT COALESCE(SUM(valor),0) v FROM lancamentos WHERE {where}", args, one=True)["v"]
    resumo = {
        "recebido": soma("tipo='receita' AND substr(pagamento,1,7)=?", (mes,)),
        "a_receber": soma("tipo='receita' AND pagamento IS NULL AND substr(vencimento,1,7)=?", (mes,)),
        "despesas": soma("tipo='despesa' AND substr(pagamento,1,7)=?", (mes,)),
        "despesas_pend": soma("tipo='despesa' AND pagamento IS NULL AND substr(vencimento,1,7)=?", (mes,)),
        "atrasado": soma("tipo='receita' AND pagamento IS NULL AND vencimento < ?", (hoje().isoformat(),)),
    }
    resumo["saldo"] = resumo["recebido"] - resumo["despesas"]
    # últimos 6 meses
    historico = []
    for i in range(5, -1, -1):
        y, m = ref.year, ref.month - i
        while m <= 0:
            m += 12
            y -= 1
        chave = f"{y:04d}-{m:02d}"
        historico.append({
            "mes": f"{MESES[m - 1][:3]}/{str(y)[2:]}",
            "receitas": soma("tipo='receita' AND substr(pagamento,1,7)=?", (chave,)),
            "despesas": soma("tipo='despesa' AND substr(pagamento,1,7)=?", (chave,)),
        })
    sessoes_mes = q("""SELECT COUNT(*) n FROM atendimentos WHERE substr(inicio,1,7)=? AND status='realizado'""",
                    (mes,), one=True)["n"]
    anterior = (ref.replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
    proximo = (ref.replace(day=28) + timedelta(days=4)).strftime("%Y-%m")
    return render_template("financeiro.html", lancs=lancs, resumo=resumo, mes=mes, ref=ref, MESES=MESES,
                           anterior=anterior, proximo=proximo, filtro=filtro, historico=historico,
                           sessoes_mes=sessoes_mes, FORMAS=FORMAS_PAGAMENTO)

def form_lancamento():
    f = request.form
    return {
        "tipo": f.get("tipo") if f.get("tipo") in ("receita", "despesa") else "receita",
        "descricao": (f.get("descricao") or "").strip(),
        "categoria": (f.get("categoria") or "").strip() or None,
        "valor": numero(f.get("valor")) or 0,
        "vencimento": f.get("vencimento") or hoje().isoformat(),
        "pagamento": f.get("pagamento") or None,
        "forma_pagamento": f.get("forma_pagamento") or None,
        "paciente_id": f.get("paciente_id", type=int) or None,
    }

@app.route("/lancamentos/novo", methods=["GET", "POST"])
def lancamento_novo():
    if request.method == "POST":
        d = form_lancamento()
        repetir = max(1, min(int(request.form.get("repetir") or 1), 36))
        venc = parse_data(d["vencimento"])
        for i in range(repetir):
            m = venc.month - 1 + i
            dv = venc.replace(year=venc.year + m // 12, month=m % 12 + 1, day=min(venc.day, 28))
            d2 = dict(d, vencimento=dv.isoformat() if i else d["vencimento"], pagamento=d["pagamento"] if i == 0 else None)
            x(f"INSERT INTO lancamentos ({','.join(d2)}) VALUES ({','.join('?' * len(d2))})", list(d2.values()))
        flash("Lançamento registrado.", "ok")
        return redirect(url_for("financeiro", mes=d["vencimento"][:7]))
    l = {"tipo": request.args.get("tipo", "receita"), "vencimento": hoje().isoformat(),
         "paciente_id": request.args.get("paciente_id", type=int)}
    return render_template("lancamento_form.html", l=l, pacientes=q("SELECT id, nome FROM pacientes ORDER BY nome COLLATE NOCASE"),
                           FORMAS=FORMAS_PAGAMENTO, CATEGORIAS=CATEGORIAS_DESPESA, novo=True)

@app.route("/lancamentos/<int:lid>/editar", methods=["GET", "POST"])
def lancamento_editar(lid):
    l = q("SELECT * FROM lancamentos WHERE id = ?", (lid,), one=True) or abort(404)
    if request.method == "POST":
        d = form_lancamento()
        x(f"UPDATE lancamentos SET {','.join(k + '=?' for k in d)} WHERE id = ?", list(d.values()) + [lid])
        flash("Lançamento atualizado.", "ok")
        return redirect(url_for("financeiro", mes=d["vencimento"][:7]))
    return render_template("lancamento_form.html", l=l, pacientes=q("SELECT id, nome FROM pacientes ORDER BY nome COLLATE NOCASE"),
                           FORMAS=FORMAS_PAGAMENTO, CATEGORIAS=CATEGORIAS_DESPESA, novo=False)

@app.route("/lancamentos/<int:lid>/pagar", methods=["POST"])
def lancamento_pagar(lid):
    l = q("SELECT * FROM lancamentos WHERE id = ?", (lid,), one=True) or abort(404)
    if l["pagamento"]:
        x("UPDATE lancamentos SET pagamento = NULL, forma_pagamento = NULL WHERE id = ?", (lid,))
        flash("Pagamento desfeito.", "ok")
    else:
        x("UPDATE lancamentos SET pagamento = ?, forma_pagamento = ? WHERE id = ?",
          (request.form.get("data") or hoje().isoformat(), request.form.get("forma_pagamento") or "Pix", lid))
        flash("Pagamento registrado.", "ok")
    return redirect(request.form.get("voltar") or url_for("financeiro"))

@app.route("/lancamentos/<int:lid>/excluir", methods=["POST"])
def lancamento_excluir(lid):
    x("DELETE FROM lancamentos WHERE id = ?", (lid,))
    flash("Lançamento excluído.", "ok")
    return redirect(request.form.get("voltar") or url_for("financeiro"))

@app.route("/recibo")
def recibo():
    """Recibo de um ou vários lançamentos: /recibo?ids=1,2,3"""
    ids = [int(i) for i in request.args.get("ids", "").split(",") if i.strip().isdigit()]
    if not ids:
        abort(404)
    lancs = q(f"SELECT * FROM lancamentos WHERE id IN ({','.join('?' * len(ids))}) ORDER BY vencimento", ids)
    if not lancs:
        abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (lancs[0]["paciente_id"],), one=True)
    total = sum(l["valor"] for l in lancs)
    return render_template("recibo.html", lancs=lancs, p=p, total=total, extenso=valor_extenso(total))

@app.route("/pacientes/<int:pid>/recibo-mensal")
def recibo_mensal(pid):
    mes = request.args.get("mes") or hoje().strftime("%Y-%m")
    ids = [r["id"] for r in q("""SELECT id FROM lancamentos WHERE paciente_id = ? AND tipo='receita'
                                 AND pagamento IS NOT NULL AND substr(vencimento,1,7) = ?""", (pid, mes))]
    if not ids:
        flash("Não há pagamentos registrados para este paciente neste mês.", "erro")
        return redirect(url_for("paciente", pid=pid) + "#financeiro")
    return redirect(url_for("recibo", ids=",".join(map(str, ids))))


# ------------------------------------------------------------------ lembretes WhatsApp
def telefone_lembrete(p):
    i = idade(p["nascimento"])
    if p["responsavel_telefone"] and (i is not None and i < 18 or not p["telefone"]):
        return p["responsavel_telefone"]
    return p["telefone"] or p["responsavel_telefone"]

@app.route("/lembretes")
def lembretes():
    s = carregar_settings()
    dias = request.args.get("dias", 3, type=int)
    inicio = agora().strftime("%Y-%m-%dT%H:%M")
    fim = (hoje() + timedelta(days=dias + 1)).isoformat()
    rows = q("""SELECT a.*, p.nome, p.telefone, p.responsavel_telefone, p.nascimento, p.id pid
                FROM atendimentos a JOIN pacientes p ON p.id = a.paciente_id
                WHERE a.inicio >= ? AND a.inicio < ? AND a.status IN ('agendado','confirmado')
                ORDER BY a.inicio""", (inicio, fim))
    itens = []
    for a in rows:
        p = q("SELECT * FROM pacientes WHERE id = ?", (a["pid"],), one=True)
        tel = telefone_lembrete(p)
        msg = whatsapp.montar_mensagem(s["msg_lembrete"], whatsapp.campos_mensagem(a, p, s))
        itens.append({"a": a, "tel": tel, "msg": msg, "link": whatsapp.link_wa(tel, msg)})
    return render_template("lembretes.html", itens=itens, dias=dias, modo=s["whatsapp_modo"])

@app.route("/api/atendimentos/<int:aid>/lembrete", methods=["POST"])
def api_lembrete_marcar(aid):
    x("UPDATE atendimentos SET lembrete_enviado_em = ? WHERE id = ?", (agora().isoformat(timespec="minutes"), aid))
    return jsonify(ok=True)

@app.route("/atendimentos/<int:aid>/lembrete-api", methods=["POST"])
def lembrete_api(aid):
    a = q("SELECT * FROM atendimentos WHERE id = ?", (aid,), one=True) or abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (a["paciente_id"],), one=True)
    s = carregar_settings()
    ok, det = whatsapp.enviar_api(s, telefone_lembrete(p), whatsapp.campos_mensagem(a, p, s))
    if ok:
        x("UPDATE atendimentos SET lembrete_enviado_em = ? WHERE id = ?", (agora().isoformat(timespec="minutes"), aid))
        flash("Lembrete enviado automaticamente pelo WhatsApp.", "ok")
    else:
        flash(f"Não foi possível enviar: {det}", "erro")
    return redirect(request.form.get("voltar") or url_for("lembretes"))

def ciclo_lembretes():
    """Roda em segundo plano: envia lembretes automáticos quando o modo automático está ativo."""
    while True:
        try:
            con = conectar()
            s = carregar_settings(con)
            if s.get("whatsapp_modo") == "automatico" and s.get("wa_token") and s.get("wa_phone_id"):
                antecedencia = int(s.get("lembrete_antecedencia_horas") or 24)
                now = agora()
                limite = (now + timedelta(hours=antecedencia)).strftime("%Y-%m-%dT%H:%M")
                rows = con.execute("""SELECT a.*, p.nome, p.telefone, p.responsavel_telefone, p.nascimento,
                                       p.id pid FROM atendimentos a JOIN pacientes p ON p.id = a.paciente_id
                                       WHERE a.inicio > ? AND a.inicio <= ? AND a.status IN ('agendado','confirmado')
                                       AND a.lembrete_enviado_em IS NULL""",
                                   (now.strftime("%Y-%m-%dT%H:%M"), limite)).fetchall()
                for a in rows:
                    p = con.execute("SELECT * FROM pacientes WHERE id = ?", (a["pid"],)).fetchone()
                    ok, det = whatsapp.enviar_api(s, telefone_lembrete(p), whatsapp.campos_mensagem(a, p, s))
                    marca = now.isoformat(timespec="minutes") if ok else None
                    if ok:
                        con.execute("UPDATE atendimentos SET lembrete_enviado_em = ? WHERE id = ?", (marca, a["id"]))
                        con.commit()
                    else:
                        app.logger.warning("Lembrete %s não enviado: %s", a["id"], det)
            con.close()
        except Exception:  # nunca derrubar o ciclo
            app.logger.exception("Erro no ciclo de lembretes")
        time.sleep(300)

_ciclo_iniciado = False

def iniciar_ciclo():
    global _ciclo_iniciado
    if not _ciclo_iniciado:
        _ciclo_iniciado = True
        threading.Thread(target=ciclo_lembretes, daemon=True).start()


# ------------------------------------------------------------------ IA: transcrição, evolução e supervisão
TMP_DIR = os.path.join(DATA_DIR, "tmp")
os.makedirs(TMP_DIR, exist_ok=True)
for _f in os.listdir(TMP_DIR):  # restos de processamentos interrompidos
    try:
        os.remove(os.path.join(TMP_DIR, _f))
    except OSError:
        pass

def chave_ia(s, nome):
    env = {"anthropic_api_key": "ANTHROPIC_API_KEY", "assemblyai_api_key": "ASSEMBLYAI_API_KEY"}[nome]
    return os.environ.get(env) or s.get(nome) or ""

def md_seguro(texto):
    """Markdown -> HTML sem permitir HTML vindo do texto."""
    texto = (texto or "").replace("&", "&amp;").replace("<", "&lt;")
    # sublistas com 2 ou 3 espaços (comum em respostas de IA) -> 4 espaços
    texto = re.sub(r"^( {2,3})(?=[-*+] |\d+\. )", "    ", texto, flags=re.M)
    return md.markdown(texto, extensions=["tables", "sane_lists"])

app.jinja_env.filters["md"] = md_seguro

def contexto_ia(con, sid):
    """Reúne os dados (pseudonimizados) que acompanham a transcrição."""
    r = con.execute("SELECT * FROM sessoes_ia WHERE id = ?", (sid,)).fetchone()
    p = con.execute("SELECT * FROM pacientes WHERE id = ?", (r["paciente_id"],)).fetchone()
    a = con.execute("SELECT * FROM atendimentos WHERE id = ?", (r["atendimento_id"],)).fetchone() if r["atendimento_id"] else None
    an = con.execute("SELECT * FROM anamneses WHERE paciente_id = ?", (p["id"],)).fetchone()
    s = carregar_settings(con)
    nomes = [p["nome"], p["responsavel_nome"]]
    ps = lambda t: ia.pseudonimizar(t, nomes)
    data_ref = (a["inicio"] if a else r["criado_em"])[:10]
    numero = con.execute("""SELECT COUNT(*) FROM atendimentos WHERE paciente_id = ? AND status = 'realizado'
                            AND inicio <= ?""", (p["id"], (a["inicio"] if a else data_ref + "T23:59"))).fetchone()[0]
    evols = con.execute("""SELECT data, texto FROM evolucoes WHERE paciente_id = ? AND data < ?
                           ORDER BY data DESC, id DESC LIMIT 3""", (p["id"], data_ref)).fetchall()
    plano = con.execute("""SELECT proxima_sessao FROM sessoes_ia WHERE paciente_id = ? AND status = 'pronto'
                           AND id != ? AND substr(criado_em,1,10) <= ? ORDER BY id DESC LIMIT 1""",
                        (p["id"], sid, data_ref)).fetchone()
    aval = con.execute("""SELECT hipoteses FROM avaliacoes WHERE paciente_id = ? AND status != 'Concluída'
                          ORDER BY id DESC LIMIT 1""", (p["id"],)).fetchone()
    tipo = a["tipo"] if a else ""
    return {
        "abordagem": p["abordagem"] or s.get("abordagem_padrao") or "TCC",
        "eh_avaliacao": "Avaliação" in (tipo or ""),
        "codigo": ia.iniciais(p["nome"]),
        "idade": idade(p["nascimento"]),
        "sexo": p["sexo"],
        "escolaridade": p["escolaridade"],
        "data": data_br(data_ref),
        "numero": numero or None,
        "tipo": tipo,
        "modalidade": a["modalidade"] if a else "",
        "duracao": a["duracao_min"] if a else s.get("duracao_padrao"),
        "queixa": ps(an["queixa"]) if an else None,
        "historico": ps(an["historico"]) if an else None,
        "hipoteses": ps(aval["hipoteses"]) if aval else None,
        "plano_anterior": ps(plano["proxima_sessao"]) if plano else None,
        "evolucoes_anteriores": [(data_br(e["data"]), ps(e["texto"])) for e in evols],
        "observacao": ps(r["observacao"]),
        "transcricao": ps(r["transcricao"]),
    }

def processar_ia(sid, caminho_audio=None):
    """Roda em segundo plano: transcreve (se houver áudio) e gera a análise."""
    con = conectar()
    def atualizar(**campos):
        con.execute(f"UPDATE sessoes_ia SET {','.join(k + '=?' for k in campos)} WHERE id = ?",
                    list(campos.values()) + [sid])
        con.commit()
    try:
        s = carregar_settings(con)
        if caminho_audio:
            texto = ia.transcrever(caminho_audio, chave_ia(s, "assemblyai_api_key"))
            if not texto.strip():
                raise ia.ErroIA("A transcrição veio vazia. Verifique se o áudio foi gravado corretamente.")
            atualizar(transcricao=texto, status="analisando")
        ctx = contexto_ia(con, sid)
        res = ia.analisar(ctx, chave_ia(s, "anthropic_api_key"))
        campos = dict(status="pronto", evolucao=res["evolucao"], analise_caso=res["analise_caso"],
                      feedback_atuacao=res["feedback_atuacao"], proxima_sessao=res["proxima_sessao"],
                      alerta_risco=1 if res["alerta_risco"] else 0, resumo_alerta=res["resumo_alerta"],
                      abordagem=ctx["abordagem"], erro=None, tokens_entrada=res["_uso"]["entrada"],
                      tokens_saida=res["_uso"]["saida"], concluido_em=agora().isoformat(timespec="minutes"))
        if s.get("apagar_transcricao") == "1":
            campos["transcricao"] = None
        atualizar(**campos)
    except ia.ErroIA as e:
        atualizar(status="erro", erro=str(e))
    except Exception as e:  # erro inesperado: registra e não derruba o servidor
        app.logger.exception("Falha no processamento de IA %s", sid)
        atualizar(status="erro", erro=f"Erro inesperado: {e}")
    finally:
        con.close()
        if caminho_audio and os.path.exists(caminho_audio):
            os.remove(caminho_audio)  # o áudio nunca fica guardado

def iniciar_ia(sid, caminho_audio=None):
    threading.Thread(target=processar_ia, args=(sid, caminho_audio), daemon=True).start()

def nova_sessao_ia(a, status, origem, transcricao=None):
    return x("""INSERT INTO sessoes_ia (atendimento_id, paciente_id, status, origem, observacao, transcricao, criado_em)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
             (a["id"], a["paciente_id"], status, origem, (request.form.get("observacao") or "").strip() or None,
              transcricao, agora().isoformat(timespec="minutes")))

def exigir_consentimento(a):
    p = q("SELECT consentimento_ia FROM pacientes WHERE id = ?", (a["paciente_id"],), one=True)
    return bool(p and p["consentimento_ia"])

@app.route("/atendimentos/<int:aid>/gravar")
def gravar(aid):
    a = q("SELECT * FROM atendimentos WHERE id = ?", (aid,), one=True) or abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (a["paciente_id"],), one=True)
    s = carregar_settings()
    return render_template("gravar.html", a=a, p=p,
                           falta_chave=not (chave_ia(s, "assemblyai_api_key") and chave_ia(s, "anthropic_api_key")))

@app.route("/atendimentos/<int:aid>/audio", methods=["POST"])
def receber_audio(aid):
    a = q("SELECT * FROM atendimentos WHERE id = ?", (aid,), one=True) or abort(404)
    if not exigir_consentimento(a):
        return jsonify(ok=False, erro="Registre o consentimento do paciente antes de enviar a gravação."), 400
    arq = request.files.get("audio")
    if not arq:
        return jsonify(ok=False, erro="Nenhum arquivo recebido."), 400
    ext = os.path.splitext(arq.filename or "")[1].lower()[:6] or ".webm"
    caminho = os.path.join(TMP_DIR, f"{uuid.uuid4().hex}{ext}")
    arq.save(caminho)
    sid = nova_sessao_ia(a, "transcrevendo", request.form.get("origem") or "arquivo")
    iniciar_ia(sid, caminho)
    destino = url_for("sessao_ia", sid=sid)
    if request.headers.get("X-CSRF"):
        return jsonify(ok=True, url=destino)
    return redirect(destino)

@app.route("/atendimentos/<int:aid>/transcricao", methods=["POST"])
def receber_transcricao(aid):
    a = q("SELECT * FROM atendimentos WHERE id = ?", (aid,), one=True) or abort(404)
    if not exigir_consentimento(a):
        flash("Registre o consentimento do paciente antes de usar a IA.", "erro")
        return redirect(url_for("atendimento", aid=aid))
    texto = (request.form.get("transcricao") or "").strip()
    arq = request.files.get("arquivo")
    if arq and arq.filename:
        texto = arq.read().decode("utf-8", errors="replace").strip()
    if len(texto) < 200:
        flash("A transcrição está muito curta. Cole o texto completo da sessão.", "erro")
        return redirect(url_for("gravar", aid=aid) + "#texto")
    sid = nova_sessao_ia(a, "analisando", "texto", texto)
    iniciar_ia(sid)
    return redirect(url_for("sessao_ia", sid=sid))

@app.route("/sessoes-ia/<int:sid>")
def sessao_ia(sid):
    r = q("SELECT * FROM sessoes_ia WHERE id = ?", (sid,), one=True) or abort(404)
    p = q("SELECT * FROM pacientes WHERE id = ?", (r["paciente_id"],), one=True)
    a = q("SELECT * FROM atendimentos WHERE id = ?", (r["atendimento_id"],), one=True) if r["atendimento_id"] else None
    evol = q("SELECT * FROM evolucoes WHERE atendimento_id = ?", (a["id"],), one=True) if a else None
    custo = None
    if r["tokens_entrada"]:
        custo = (r["tokens_entrada"] * 4 + r["tokens_saida"] * 20) / 1_000_000
    return render_template("sessao_ia.html", r=r, p=p, a=a, evol=evol, custo=custo)

@app.route("/api/sessoes-ia/<int:sid>")
def api_sessao_ia(sid):
    r = q("SELECT status, erro FROM sessoes_ia WHERE id = ?", (sid,), one=True) or abort(404)
    return jsonify(status=r["status"], erro=r["erro"])

@app.route("/sessoes-ia/<int:sid>/reanalisar", methods=["POST"])
def reanalisar(sid):
    r = q("SELECT * FROM sessoes_ia WHERE id = ?", (sid,), one=True) or abort(404)
    if not r["transcricao"]:
        flash("A transcrição desta sessão não está mais guardada; não é possível refazer a análise.", "erro")
        return redirect(url_for("sessao_ia", sid=sid))
    x("UPDATE sessoes_ia SET status = 'analisando', erro = NULL, observacao = COALESCE(?, observacao) WHERE id = ?",
      ((request.form.get("observacao") or "").strip() or None, sid))
    iniciar_ia(sid)
    return redirect(url_for("sessao_ia", sid=sid))

@app.route("/sessoes-ia/<int:sid>/apagar-transcricao", methods=["POST"])
def apagar_transcricao(sid):
    x("UPDATE sessoes_ia SET transcricao = NULL WHERE id = ?", (sid,))
    flash("Transcrição apagada. A evolução e as análises foram mantidas.", "ok")
    return redirect(url_for("sessao_ia", sid=sid))

@app.route("/sessoes-ia/<int:sid>/excluir", methods=["POST"])
def excluir_sessao_ia(sid):
    r = q("SELECT * FROM sessoes_ia WHERE id = ?", (sid,), one=True) or abort(404)
    x("DELETE FROM sessoes_ia WHERE id = ?", (sid,))
    flash("Análise excluída.", "ok")
    return redirect(url_for("atendimento", aid=r["atendimento_id"]) if r["atendimento_id"] else url_for("paciente", pid=r["paciente_id"]))

@app.route("/sessoes-ia/<int:sid>/usar-evolucao", methods=["POST"])
def usar_evolucao(sid):
    r = q("SELECT * FROM sessoes_ia WHERE id = ?", (sid,), one=True) or abort(404)
    a = q("SELECT * FROM atendimentos WHERE id = ?", (r["atendimento_id"],), one=True)
    texto = request.form.get("texto", "").strip() or r["evolucao"]
    existente = q("SELECT id FROM evolucoes WHERE atendimento_id = ?", (a["id"],), one=True) if a else None
    if existente:
        x("UPDATE evolucoes SET texto = ?, atualizado_em = ? WHERE id = ?",
          (texto, agora().isoformat(timespec="minutes"), existente["id"]))
    else:
        x("INSERT INTO evolucoes (paciente_id, atendimento_id, data, texto) VALUES (?, ?, ?, ?)",
          (r["paciente_id"], a["id"] if a else None, a["inicio"][:10] if a else hoje().isoformat(), texto))
    if a and a["status"] in ("agendado", "confirmado"):
        x("UPDATE atendimentos SET status = 'realizado' WHERE id = ?", (a["id"],))
        sincronizar_financeiro(a["id"])
    flash("Evolução salva no prontuário.", "ok")
    return redirect(url_for("sessao_ia", sid=sid))

@app.route("/pacientes/<int:pid>/consentimento", methods=["POST"])
def registrar_consentimento(pid):
    data = request.form.get("data") or hoje().isoformat()
    x("UPDATE pacientes SET consentimento_ia = ? WHERE id = ?", (data if request.form.get("consentiu") else None, pid))
    flash("Consentimento registrado." if request.form.get("consentiu") else "Consentimento revogado.", "ok")
    return redirect(request.form.get("voltar") or url_for("paciente", pid=pid))


# ------------------------------------------------------------------ importação de pacientes
def _arquivo_importacao():
    tok = session.get("importacao")
    if not tok or not re.fullmatch(r"[a-f0-9]{32}", tok):
        return None
    caminho = os.path.join(TMP_DIR, f"importacao-{tok}.json")
    return caminho if os.path.exists(caminho) else None

def _previa(cab, linhas, mapa):
    pacs = importar.montar_pacientes(linhas, mapa, cab)
    existentes = q("SELECT nome, cpf FROM pacientes")
    nomes = {importar.normalizar(r["nome"]) for r in existentes}
    cpfs = {re.sub(r"\D", "", r["cpf"] or "") for r in existentes} - {""}
    vistos = set()
    for item in pacs:
        d = item["dados"]
        chave = importar.normalizar(d["nome"])
        cpf = re.sub(r"\D", "", d.get("cpf") or "")
        item["duplicado"] = chave in nomes or (cpf and cpf in cpfs) or chave in vistos
        vistos.add(chave)
    return pacs

@app.route("/pacientes/importar", methods=["GET", "POST"])
def importar_pacientes():
    if request.method == "POST":
        arq = request.files.get("arquivo")
        if not arq or not arq.filename:
            flash("Escolha o arquivo da planilha.", "erro")
            return redirect(url_for("importar_pacientes"))
        try:
            cab, linhas = importar.ler_planilha(arq.filename, arq.read())
        except importar.ErroImportacao as e:
            flash(str(e), "erro")
            return redirect(url_for("importar_pacientes"))
        tok = uuid.uuid4().hex
        with open(os.path.join(TMP_DIR, f"importacao-{tok}.json"), "w", encoding="utf-8") as f:
            json.dump({"cab": cab, "linhas": linhas, "arquivo": arq.filename}, f, default=str)
        session["importacao"] = tok
        return redirect(url_for("importar_previa"))
    return render_template("importar.html")

@app.route("/pacientes/importar/previa", methods=["GET", "POST"])
def importar_previa():
    caminho = _arquivo_importacao()
    if not caminho:
        flash("Envie a planilha novamente.", "erro")
        return redirect(url_for("importar_pacientes"))
    with open(caminho, encoding="utf-8") as f:
        dados = json.load(f)
    cab, linhas = dados["cab"], dados["linhas"]
    if request.method == "POST":
        mapa = [request.form.get(f"col_{i}", "") for i in range(len(cab))]
        mapa = [m if m in importar.ROTULOS else "" for m in mapa]
    else:
        mapa = importar.mapear_colunas(cab)
    pacs = _previa(cab, linhas, mapa)
    if request.method == "POST" and request.form.get("acao") == "confirmar":
        if "nome" not in mapa:
            flash("Indique qual coluna tem o nome do paciente.", "erro")
        else:
            padrao = carregar_settings()
            n = 0
            for item in pacs:
                if item["duplicado"]:
                    continue
                d = item["dados"]
                if d.get("abordagem") not in ia.ABORDAGENS:
                    d.pop("abordagem", None)
                cols = [c for c in CAMPOS_PACIENTE + ["ativo"] if d.get(c) not in (None, "")]
                if "valor_sessao" not in cols and padrao.get("valor_sessao_padrao"):
                    d["valor_sessao"] = numero(padrao["valor_sessao_padrao"])
                    cols.append("valor_sessao")
                x(f"INSERT INTO pacientes ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", [d[c] for c in cols])
                n += 1
            os.remove(caminho)
            session.pop("importacao", None)
            pulados = sum(1 for i in pacs if i["duplicado"])
            flash(f"{n} paciente(s) importado(s)." + (f" {pulados} já existiam e foram pulados." if pulados else ""), "ok")
            return redirect(url_for("pacientes"))
    return render_template("importar_previa.html", cab=cab, mapa=mapa, pacs=pacs, ROTULOS=importar.ROTULOS,
                           arquivo=dados["arquivo"], exemplos=linhas[:3])

@app.route("/pacientes/importar/modelo.csv")
def importar_modelo():
    linhas = ["Nome;Data de nascimento;CPF;Telefone;E-mail;Responsável;Telefone do responsável;Escolaridade;Valor da sessão;Observações",
              "Maria Exemplo da Silva;15/04/1990;123.456.789-00;(11) 91234-5678;maria@email.com;;;Superior completo;200,00;",
              "Pedro Exemplo;03/09/2015;;;;Ana Exemplo;(11) 99876-5432;4º ano;250,00;Encaminhado pela escola"]
    return app.response_class("﻿" + "\r\n".join(linhas), mimetype="text/csv",
                              headers={"Content-Disposition": "attachment; filename=modelo-pacientes.csv"})


# ------------------------------------------------------------------ relatório mensal de sessões
@app.route("/relatorios/sessoes")
def relatorio_sessoes():
    mes = request.args.get("mes") or hoje().strftime("%Y-%m")
    rows = q("""SELECT a.*, p.nome FROM atendimentos a JOIN pacientes p ON p.id = a.paciente_id
                WHERE substr(a.inicio,1,7) = ? ORDER BY p.nome COLLATE NOCASE, a.inicio""", (mes,))
    por_paciente = {}
    for a in rows:
        d = por_paciente.setdefault(a["paciente_id"], {"nome": a["nome"], "realizado": [], "falta": [], "cancelado": [], "agendado": []})
        chave = {"falta_cobrada": "falta", "confirmado": "agendado"}.get(a["status"], a["status"])
        d[chave].append(a["inicio"])
    totais = {k: sum(len(v[k]) for v in por_paciente.values()) for k in ("realizado", "falta", "cancelado", "agendado")}
    try:
        ref = datetime.strptime(mes, "%Y-%m").date()
    except ValueError:
        abort(404)
    return render_template("relatorio_sessoes.html", mes=mes, ref=ref, MESES=MESES, por_paciente=por_paciente,
                           totais=totais)


# ------------------------------------------------------------------ configurações
CAMPOS_CONFIG = ["profissional_nome", "profissional_crp", "profissional_cpf", "profissional_especialidade", "consultorio_nome",
                 "consultorio_endereco", "consultorio_telefone", "cidade", "valor_sessao_padrao", "duracao_padrao",
                 "msg_lembrete", "lembrete_antecedencia_horas", "whatsapp_modo", "wa_phone_id", "wa_template",
                 "wa_template_lang", "abordagem_padrao"]

@app.route("/configuracoes", methods=["GET", "POST"])
def config():
    if request.method == "POST":
        for c in CAMPOS_CONFIG:
            if c in request.form:
                salvar_setting(c, request.form.get(c, "").strip())
        if request.form.get("wa_token"):
            salvar_setting("wa_token", request.form["wa_token"].strip())
        if request.form.get("limpar_token"):
            salvar_setting("wa_token", "")
        for chave in ("anthropic_api_key", "assemblyai_api_key"):
            if request.form.get(chave):
                salvar_setting(chave, request.form[chave].strip())
            if request.form.get("limpar_" + chave):
                salvar_setting(chave, "")
        if "secao_ia" in request.form:
            salvar_setting("apagar_transcricao", "1" if request.form.get("apagar_transcricao") else "0")
        flash("Configurações salvas.", "ok")
        return redirect(url_for("config"))
    return render_template("config.html", usuario=q("SELECT * FROM usuarios WHERE id = ?", (session["uid"],), one=True))

@app.route("/configuracoes/senha", methods=["POST"])
def config_senha():
    u = q("SELECT * FROM usuarios WHERE id = ?", (session["uid"],), one=True)
    f = request.form
    if not check_password_hash(u["senha_hash"], f.get("atual", "")):
        flash("Senha atual incorreta.", "erro")
    elif len(f.get("nova", "")) < 8 or f.get("nova") != f.get("nova2"):
        flash("A nova senha precisa ter 8+ caracteres e ser igual nos dois campos.", "erro")
    else:
        x("UPDATE usuarios SET senha_hash = ? WHERE id = ?", (generate_password_hash(f["nova"]), u["id"]))
        flash("Senha alterada.", "ok")
    return redirect(url_for("config"))

@app.route("/configuracoes/testar-whatsapp", methods=["POST"])
def config_testar_wa():
    s = carregar_settings()
    tel = request.form.get("telefone")
    campos = {"nome": "Teste", "dia_semana": DIAS_SEMANA[hoje().weekday()], "data": hoje().strftime("%d/%m"),
              "hora": "10:00"}
    ok, det = whatsapp.enviar_api(s, tel, campos)
    flash("Mensagem de teste enviada!" if ok else f"Falhou: {det}", "ok" if ok else "erro")
    return redirect(url_for("config") + "#whatsapp")

@app.route("/backup")
def backup():
    destino = os.path.join(DATA_DIR, "backup-temp.db")
    origem = conectar()
    copia = sqlite3.connect(destino)
    origem.backup(copia)
    copia.close()
    origem.close()
    return send_file(destino, as_attachment=True,
                     download_name=f"consultorio-backup-{agora().strftime('%Y-%m-%d-%H%M')}.db")


@app.errorhandler(400)
def erro400(e):
    return render_template("erro.html", msg=e.description), 400

@app.errorhandler(404)
def erro404(e):
    return render_template("erro.html", msg="Página não encontrada."), 404


iniciar_ciclo()

if __name__ == "__main__":
    porta = int(os.environ.get("PORT", 5000))
    print(f"\n  Consultório rodando em: http://localhost:{porta}\n")
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=porta, debug=False)
