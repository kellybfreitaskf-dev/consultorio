@echo off
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul || (echo Python nao encontrado. Instale em https://www.python.org/downloads/ marcando "Add Python to PATH". & pause & exit /b)
if not exist .venv (
  echo Preparando o sistema pela primeira vez, aguarde...
  python -m venv .venv
  .venv\Scripts\python -m pip install -q -r requirements.txt
)
start "" http://localhost:5000
.venv\Scripts\python app.py
pause
