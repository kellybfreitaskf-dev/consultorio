"""Transcrição de sessões e análise clínica com IA.

- Transcrição: AssemblyAI (reconhece quem fala: psicóloga x paciente). O áudio
  é enviado, transcrito e apagado do servidor do consultório.
- Análise: Claude (Anthropic) gera, a partir da transcrição:
  1. evolução para o prontuário, 2. análise do caso com supervisão clínica,
  3. feedback sobre a atuação da psicóloga, 4. estrutura da próxima sessão,
  dentro do referencial teórico escolhido para o paciente.
"""
import json
import re
import time

import anthropic
import requests

MODELO = "claude-opus-5-5"

ABORDAGENS = {
    "TCC": "Terapia Cognitivo-Comportamental (modelo de Beck): conceitualização com situações, pensamentos "
           "automáticos, emoções, comportamentos, crenças intermediárias e centrais, estratégias compensatórias e "
           "ciclos de manutenção. Sessão estruturada: humor, ponte, revisão de tarefa, agenda, intervenção, nova "
           "tarefa, resumo e feedback. Avalie descoberta guiada e questionamento socrático.",
    "Terapia do Esquema": "Terapia do Esquema (Young): esquemas iniciais desadaptativos, domínios, necessidades "
           "emocionais não atendidas, modos (criança, pais disfuncionais, enfrentamento desadaptativo, adulto "
           "saudável), estilos de enfrentamento. Técnicas cognitivas, experienciais (imagens, cadeiras), "
           "comportamentais e reparentalização limitada; confrontação empática.",
    "DBT": "Terapia Comportamental Dialética (Linehan): hierarquia de alvos (comportamentos que ameaçam a vida, "
           "que interferem na terapia, na qualidade de vida), análise em cadeia e de soluções, cartão diário, "
           "habilidades (mindfulness, tolerância ao mal-estar, regulação emocional, efetividade interpessoal), "
           "equilíbrio validação/mudança, estratégias dialéticas.",
    "ACT": "Terapia de Aceitação e Compromisso: hexaflex (aceitação, desfusão, momento presente, self como "
           "contexto, valores, ação comprometida), inflexibilidade psicológica, esquiva experiencial, metáforas "
           "e exercícios experienciais, análise funcional da esquiva.",
    "Análise do Comportamento": "Análise do Comportamento / Terapia Analítico-Comportamental: análise funcional "
           "(antecedentes, respostas, consequências), contingências de reforço e punição, regras e "
           "autorregras, repertórios a instalar, FAP quando pertinente, modelagem na relação terapêutica.",
    "Psicanálise": "Psicanálise: associação livre e atenção flutuante, transferência e contratransferência, "
           "resistência, repetição, posição subjetiva, formações do inconsciente (atos falhos, sonhos, "
           "sintomas), manejo do enquadre e das intervenções (pontuação, interpretação, corte). Não há agenda "
           "nem tarefa de casa: adapte a estrutura da próxima sessão a pontos de escuta e hipóteses a sustentar.",
    "Psicoterapia Psicodinâmica": "Psicoterapia psicodinâmica: conflitos centrais, mecanismos de defesa, "
           "padrões relacionais repetitivos (CCRT), transferência, aliança, foco dinâmico, intervenções no "
           "continuum expressivo-suportivo. Sem tarefa de casa.",
    "Abordagem Centrada na Pessoa": "Abordagem Centrada na Pessoa (Rogers): condições facilitadoras (empatia, "
           "aceitação incondicional, congruência), tendência atualizante, incongruência self/experiência, "
           "não diretividade. Avalie a qualidade da escuta e das respostas empáticas; sem tarefa de casa.",
    "Gestalt-terapia": "Gestalt-terapia: awareness, contato e mecanismos de interrupção do contato "
           "(confluência, introjeção, projeção, retroflexão, deflexão), ciclo de contato, aqui-e-agora, "
           "experimentos, figura/fundo, situações inacabadas.",
    "Sistêmica": "Terapia sistêmica / familiar: padrões relacionais, circularidade, fronteiras, hierarquia, "
           "triangulações, ciclo de vida familiar, genograma, perguntas circulares e reflexivas, ressignificação.",
    "Reabilitação neuropsicológica": "Reabilitação neuropsicológica: metas funcionais (GAS/SMART) ligadas ao "
           "cotidiano, estratégias restaurativas, compensatórias e ambientais, aprendizagem sem erro, "
           "recuperação espaçada, treino metacognitivo, generalização, envolvimento da família/escola, "
           "monitoramento de adesão.",
}

ROTEIRO_AVALIACAO = ("Esta é uma sessão de AVALIAÇÃO neuropsicológica/psicológica. Na evolução, registre os "
    "procedimentos e instrumentos aplicados (sem escores que não constem da transcrição), o comportamento durante "
    "a testagem (atenção, colaboração, fadiga, estratégias, tolerância à frustração) e intercorrências. Na análise, "
    "relacione as observações às hipóteses diagnósticas em investigação. Na próxima sessão, proponha os próximos "
    "instrumentos ou etapas (testagem, entrevista com família/escola, devolutiva) com a justificativa.")

SISTEMA = """Você apoia uma psicóloga clínica brasileira no registro e na supervisão das suas sessões. Ela é a \
responsável técnica: você organiza, analisa e sugere; não substitui o julgamento clínico nem a supervisão humana. \
Escreva em português do Brasil, com linguagem técnica, sem explicar conceitos básicos.

A partir da transcrição recebida, produza quatro partes:

PARTE 1 — EVOLUÇÃO (vai para o prontuário, texto simples sem markdown).
Sintética e objetiva, em terceira pessoa ("a paciente relata...", "foi realizada psicoeducação sobre..."). \
Descreva, não interprete: hipóteses ficam na Parte 2. Só o que aconteceu; item não abordado = "não abordado". \
Evite detalhes íntimos que não mudem a conduta, citações longas e dados de terceiros identificáveis. \
Use estes rótulos, cada um numa linha seguida do conteúdo:
Demanda / motivo da sessão:
Relato do paciente:
Estado emocional e comportamento observados:
Intervenções realizadas:
Resposta do paciente às intervenções:
Tarefa de casa: (ou "não se aplica" se a abordagem não usa)
Risco:
Encaminhamentos / combinados:
Plano:

PARTE 2 — ANÁLISE DO CASO COM SUPERVISÃO CLÍNICA (uso interno, markdown).
Fale como um supervisor experiente NA ABORDAGEM INDICADA: direto, com hipóteses, apontando pontos cegos, sem só \
validar. Use os construtos dessa abordagem. Seções: Conceitualização do caso (atualização, e o que mudou desde as \
sessões anteriores); Intervenções: o que funcionou e o que não funcionou (com evidência na fala do paciente); \
Aliança e processo; Pontos cegos, hipóteses alternativas e oportunidades; Risco; Para levar à supervisão humana \
(1 a 3 perguntas). Diferencie "o paciente disse" de "hipótese". Não feche diagnóstico nem CID a partir de uma sessão.

PARTE 3 — FEEDBACK SOBRE A ATUAÇÃO DA PSICÓLOGA (uso interno, markdown). Trata dela, não do paciente.
Cada ponto ancorado num trecho concreto da transcrição, citado em poucas palavras, com o minuto quando houver. \
### Pontos fortes (3 a 5): habilidade, trecho, efeito no paciente.
### Pontos a melhorar (3 a 5, por prioridade), cada um com: **O que aconteceu** (trecho), **Por que importa** \
(efeito clínico), **Como fazer diferente** (alternativa concreta com frase ou pergunta de exemplo).
Dimensões: qualidade das perguntas (abertas/fechadas, indutoras, empilhadas, aprofundamento); conduta e estrutura; \
técnicas e fidelidade ao modelo da abordagem; postura (validação, ritmo, fala em excesso, interrupções, conselhos \
prematuros); aliança e manejo do processo; manejo de risco e limites.
### Foco de treino para a próxima sessão: UMA habilidade para praticar de propósito.
Avalie só o que o texto mostra (tom de voz e sinais não verbais não aparecem). Não infle pontos fortes nem invente \
falhas; se a sessão foi bem conduzida, diga isso e aponte só refinamentos reais.

PARTE 4 — ESTRUTURA DA PRÓXIMA SESSÃO (markdown).
Objetivo central; roteiro em tabela com blocos e tempo estimado para a duração informada, adaptado à abordagem \
(abordagens sem agenda ou tarefa de casa recebem pontos de escuta, temas a retomar e hipóteses a sustentar); \
o que checar (risco, adesão, medicação, se aplicável); Plano B se o paciente chegar em crise ou com tema novo.

RISCO: procure indicadores de ideação suicida, autolesão, violência (sofrida ou praticada), violência doméstica, \
abuso, uso de substâncias ou crise. Se houver qualquer indicador, marque alerta_risco = true, descreva o trecho em \
resumo_alerta e abra a Parte 2 com um bloco "> **ALERTA DE RISCO:** ..." recomendando avaliação de risco. Se não \
houver, alerta_risco = false e escreva "sem indicadores de risco na sessão" no item Risco.

A transcrição vem de reconhecimento automático de fala e pode ter erros; os falantes aparecem como "Falante A/B": \
deduza pelo conteúdo quem é a psicóloga. Trechos inaudíveis ou confusos devem ser registrados como tal, nunca \
preenchidos. Nomes de pessoas foram substituídos por iniciais por privacidade: mantenha as iniciais."""

SCHEMA = {
    "type": "object",
    "properties": {
        "evolucao": {"type": "string", "description": "Parte 1, texto simples para o prontuário"},
        "analise_caso": {"type": "string", "description": "Parte 2, markdown"},
        "feedback_atuacao": {"type": "string", "description": "Parte 3, markdown"},
        "proxima_sessao": {"type": "string", "description": "Parte 4, markdown"},
        "alerta_risco": {"type": "boolean"},
        "resumo_alerta": {"type": "string", "description": "Vazio se não houver alerta"},
    },
    "required": ["evolucao", "analise_caso", "feedback_atuacao", "proxima_sessao", "alerta_risco", "resumo_alerta"],
    "additionalProperties": False,
}


class ErroIA(Exception):
    pass


# ------------------------------------------------------------------ privacidade
def iniciais(nome):
    partes = [p for p in (nome or "").split() if len(p) > 2 or p[:1].isupper()]
    return ".".join(p[0].upper() for p in partes if p[:1].isalpha()) + "." if partes else "P."

def pseudonimizar(texto, nomes):
    """Troca nomes de pessoas pelas iniciais: primeiro os nomes completos, depois os
    primeiros nomes e por fim os sobrenomes (um sobrenome comum fica com quem vem antes)."""
    if not texto:
        return texto
    pessoas = [(n, iniciais(n)) for n in nomes if n and n.strip()]
    trocas = [(n, ini) for n, ini in pessoas]
    trocas += [(n.split()[0], ini) for n, ini in pessoas]
    trocas += [(parte, ini) for n, ini in pessoas for parte in n.split()[1:]
               if len(parte) >= 3 and parte.lower() not in ("dos", "das")]
    feitos = set()
    for termo, ini in trocas:
        if len(termo) < 3 or termo.lower() in feitos:
            continue
        feitos.add(termo.lower())
        texto = re.sub(r"(?<!\w)" + re.escape(termo) + r"(?!\w)", ini, texto, flags=re.IGNORECASE)
    for _, ini in pessoas:  # "J.P.L. J.P.L." -> "J.P.L."
        texto = re.sub(r"(" + re.escape(ini) + r")(\s+" + re.escape(ini) + r")+", r"\1", texto)
    return texto


# ------------------------------------------------------------------ transcrição (AssemblyAI)
AAI = "https://api.assemblyai.com/v2"

def transcrever(caminho_audio, chave, ao_progredir=None):
    """Envia o áudio, espera a transcrição e devolve o texto com falantes e minutos."""
    if not chave:
        raise ErroIA("Chave da AssemblyAI não configurada (Configurações → Inteligência artificial).")
    cab = {"authorization": chave}
    with open(caminho_audio, "rb") as f:
        r = requests.post(f"{AAI}/upload", headers=cab, data=f, timeout=600)
    if not r.ok:
        raise ErroIA(f"Falha ao enviar o áudio para transcrição ({r.status_code}): {r.text[:200]}")
    url = r.json()["upload_url"]
    r = requests.post(f"{AAI}/transcript", headers=cab, timeout=60, json={
        "audio_url": url, "language_code": "pt", "speaker_labels": True, "punctuate": True, "format_text": True,
    })
    if not r.ok:
        raise ErroIA(f"Falha ao iniciar a transcrição ({r.status_code}): {r.text[:200]}")
    tid = r.json()["id"]
    inicio = time.time()
    while True:
        time.sleep(5)
        r = requests.get(f"{AAI}/transcript/{tid}", headers=cab, timeout=60)
        dados = r.json()
        if dados.get("status") == "completed":
            break
        if dados.get("status") == "error":
            raise ErroIA("Erro na transcrição: " + str(dados.get("error")))
        if time.time() - inicio > 3600:
            raise ErroIA("A transcrição demorou mais de 1 hora e foi interrompida.")
        if ao_progredir:
            ao_progredir(dados.get("status"))
    # apaga a cópia guardada pela AssemblyAI (o texto já está conosco)
    try:
        requests.delete(f"{AAI}/transcript/{tid}", headers=cab, timeout=30)
    except requests.RequestException:
        pass
    falas = dados.get("utterances") or []
    if not falas:
        return dados.get("text") or ""
    linhas = []
    for u in falas:
        seg = int((u.get("start") or 0) / 1000)
        linhas.append(f"[{seg // 60:02d}:{seg % 60:02d}] Falante {u.get('speaker')}: {u.get('text', '').strip()}")
    return "\n".join(linhas)


# ------------------------------------------------------------------ análise (Claude)
def montar_contexto(ctx):
    """ctx: dict com dados já pseudonimizados."""
    abordagem = ctx.get("abordagem") or "TCC"
    partes = [
        f"Referencial teórico desta paciente: **{abordagem}**.",
        "Orientação para a abordagem: " + ABORDAGENS.get(abordagem, abordagem),
    ]
    if ctx.get("eh_avaliacao"):
        partes.append(ROTEIRO_AVALIACAO)
    partes.append("\n## Dados da sessão")
    for rot, chave in [("Paciente", "codigo"), ("Idade", "idade"), ("Sexo", "sexo"), ("Escolaridade", "escolaridade"),
                       ("Data da sessão", "data"), ("Sessão nº", "numero"), ("Tipo de atendimento", "tipo"),
                       ("Modalidade", "modalidade"), ("Duração prevista (min)", "duracao")]:
        if ctx.get(chave) not in (None, ""):
            partes.append(f"- {rot}: {ctx[chave]}")
    if ctx.get("queixa"):
        partes.append("\n## Queixa principal (anamnese)\n" + ctx["queixa"])
    if ctx.get("historico"):
        partes.append("\n## Histórico (anamnese)\n" + ctx["historico"])
    if ctx.get("hipoteses"):
        partes.append("\n## Hipóteses em investigação\n" + ctx["hipoteses"])
    if ctx.get("plano_anterior"):
        partes.append("\n## Plano que havia sido feito para esta sessão\n" + ctx["plano_anterior"])
    if ctx.get("evolucoes_anteriores"):
        partes.append("\n## Evoluções das sessões anteriores (mais recente primeiro)")
        for data, texto in ctx["evolucoes_anteriores"]:
            partes.append(f"### {data}\n{texto}")
    if ctx.get("observacao"):
        partes.append("\n## Observação da psicóloga sobre esta sessão\n" + ctx["observacao"])
    partes.append("\n## Transcrição da sessão\n<transcricao>\n" + ctx["transcricao"] + "\n</transcricao>")
    return "\n".join(partes)

def analisar(ctx, chave):
    if not chave:
        raise ErroIA("Chave da API do Claude não configurada (Configurações → Inteligência artificial).")
    cliente = anthropic.Anthropic(api_key=chave, timeout=900, max_retries=3)
    pedido = dict(
        model=MODELO,
        max_tokens=32000,
        output_config={"effort": "high", "format": {"type": "json_schema", "schema": SCHEMA}},
        system=SISTEMA,
        messages=[{"role": "user", "content": montar_contexto(ctx)}],
    )
    try:
        try:
            # com modelo reserva automático caso o principal recuse o conteúdo
            with cliente.beta.messages.stream(betas=["server-side-fallback-2026-07-01"], fallbacks="default",
                                              **pedido) as stream:
                resposta = stream.get_final_message()
        except anthropic.BadRequestError as e:
            if "fallback" not in str(e.message).lower():
                raise
            with cliente.messages.stream(**pedido) as stream:
                resposta = stream.get_final_message()
    except anthropic.AuthenticationError:
        raise ErroIA("A chave da API do Claude é inválida. Confira em Configurações.")
    except anthropic.PermissionDeniedError:
        raise ErroIA("A chave da API do Claude não tem permissão. Verifique créditos e permissões no console da Anthropic.")
    except anthropic.RateLimitError:
        raise ErroIA("Limite de uso da API atingido. Tente novamente em alguns minutos.")
    except anthropic.BadRequestError as e:
        raise ErroIA(f"Pedido recusado pela API: {e.message}")
    except anthropic.APIStatusError as e:
        raise ErroIA(f"Erro no serviço do Claude ({e.status_code}). Tente novamente mais tarde.")
    except anthropic.APIConnectionError:
        raise ErroIA("Sem conexão com o serviço do Claude. Tente novamente.")
    if resposta.stop_reason == "refusal":
        raise ErroIA("O modelo não processou esta transcrição (recusa de segurança). Registre a evolução manualmente.")
    if resposta.stop_reason == "max_tokens":
        raise ErroIA("A resposta ficou longa demais e foi cortada. Tente novamente.")
    texto = next((b.text for b in resposta.content if b.type == "text"), None)
    if not texto:
        raise ErroIA("Resposta vazia do modelo.")
    try:
        dados = json.loads(texto)
    except json.JSONDecodeError:
        raise ErroIA("Resposta em formato inesperado. Tente novamente.")
    dados["_uso"] = {"entrada": resposta.usage.input_tokens, "saida": resposta.usage.output_tokens}
    return dados


# ------------------------------------------------------------------ evolução SOAP e resumo do prontuário
PEDIDO_SOAP = """Escreva a evolução desta sessão de psicoterapia no formato SOAP, para o prontuário psicológico.

Regras:
- Seja sintética: só o essencial para a continuidade do cuidado (Resolução CFP 01/2009). No máximo ~250 palavras.
- Texto simples, sem markdown, exatamente com estes quatro rótulos, cada um no início de uma linha:
S: (subjetivo: demanda e relato da paciente, em terceira pessoa)
O: (objetivo: humor, afeto, comportamento e engajamento observados; só o que o material sustenta)
A: (avaliação: compreensão clínica na abordagem {abordagem}, temas centrais, risco — escreva "sem indicadores de risco" se for o caso)
P: (plano: intervenções combinadas, tarefa, foco da próxima sessão)
- Descreva, não invente. Se algo não aparece no material, escreva "não abordado".
- Evite detalhes íntimos que não mudem a conduta, citações longas e dados de terceiros identificáveis.
- A transcrição é automática, pode ter erros e não identifica quem fala: deduza pelo conteúdo.
- Os nomes foram trocados por iniciais por privacidade: mantenha as iniciais.
- Responda apenas com a evolução, sem comentários antes ou depois."""

PEDIDO_RESUMO = """Faça um RESUMO DO PRONTUÁRIO desta paciente em no máximo uma página, para eu retomar o caso rapidamente.

Estrutura (texto simples, sem markdown, com estes títulos em linhas próprias):
Identificação e demanda:
Hipóteses / diagnóstico em investigação:
Evolução do processo até aqui:
Intervenções que funcionaram:
Pontos de atenção e risco:
Foco atual e próximos passos:

Seja objetiva, use só o que está no material, e mantenha as iniciais no lugar dos nomes. Responda apenas com o resumo."""

def gerar_texto(prompt, material, chave, max_tokens=4000):
    """Chamada simples ao Claude (opcional: só quando há chave cadastrada)."""
    if not chave:
        raise ErroIA("Chave da API do Claude não configurada.")
    cliente = anthropic.Anthropic(api_key=chave, timeout=300, max_retries=2)
    try:
        resp = cliente.messages.create(
            model=MODELO, max_tokens=max_tokens, output_config={"effort": "medium"},
            messages=[{"role": "user", "content": prompt + "\n\n" + material}])
    except anthropic.AuthenticationError:
        raise ErroIA("A chave da API do Claude é inválida.")
    except anthropic.APIStatusError as e:
        raise ErroIA(f"Erro no serviço do Claude ({e.status_code}).")
    except anthropic.APIConnectionError:
        raise ErroIA("Sem conexão com o serviço do Claude.")
    if resp.stop_reason == "refusal":
        raise ErroIA("O modelo não processou este material.")
    texto = "".join(b.text for b in resp.content if b.type == "text").strip()
    if not texto:
        raise ErroIA("Resposta vazia do modelo.")
    return texto
