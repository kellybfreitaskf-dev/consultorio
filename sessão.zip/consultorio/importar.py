"""Importação de pacientes a partir de planilha (.xlsx ou .csv)."""
import csv
import io
import re
import unicodedata
from datetime import date, datetime, timedelta

from util import numero

# campo do sistema -> nomes de coluna aceitos (já normalizados: minúsculas, sem acento)
SINONIMOS = {
    "nome": ["nome", "nome completo", "paciente", "nome do paciente", "cliente", "nome paciente"],
    "nascimento": ["nascimento", "data de nascimento", "data nascimento", "dt nascimento", "dt nasc", "data nasc",
                   "nasc", "aniversario", "data de nasc"],
    "cpf": ["cpf", "cpf do paciente", "documento"],
    "sexo": ["sexo", "genero"],
    "telefone": ["telefone", "celular", "whatsapp", "fone", "tel", "telefone celular", "contato", "telefone 1"],
    "email": ["email", "e mail", "correio eletronico"],
    "endereco": ["endereco", "endereco completo"],
    "endereco_parte": ["logradouro", "rua", "numero", "n", "complemento", "bairro", "cidade", "municipio", "uf",
                       "estado", "cep"],
    "escolaridade": ["escolaridade", "serie", "ano escolar", "escola"],
    "profissao": ["profissao", "ocupacao"],
    "responsavel_nome": ["responsavel", "nome do responsavel", "responsavel nome", "mae", "pai", "nome da mae",
                         "responsavel legal", "responsavel legal nome"],
    "responsavel_cpf": ["cpf do responsavel", "cpf responsavel", "responsavel legal cpf", "responsavel cpf"],
    "responsavel_telefone": ["telefone do responsavel", "celular do responsavel", "whatsapp do responsavel",
                             "telefone responsavel", "contato do responsavel", "responsavel legal telefone",
                             "responsavel telefone"],
    "resp_fin_nome": ["responsavel financeiro nome", "responsavel financeiro"],
    "resp_fin_cpf": ["responsavel financeiro cpf"],
    "resp_fin_telefone": ["responsavel financeiro telefone"],
    "convenio": ["convenio", "plano", "plano de saude"],
    "valor_sessao": ["valor", "valor da sessao", "valor sessao", "preco", "honorarios"],
    "observacoes": ["observacoes", "observacao", "obs", "anotacoes"],
    "abordagem": ["abordagem", "referencial", "referencial teorico"],
    "status": ["status", "situacao"],
    "extra": ["dominancia manual", "lateralidade", "n do prontuario", "numero do prontuario", "prontuario",
              "contato de emergencia nome", "contato de emergencia telefone", "contato de emergencia relacao",
              "contato de emergencia", "responsavel legal parentesco", "parentesco", "responsavel financeiro e mail",
              "responsavel financeiro email", "etiquetas", "tags", "nome social", "rg", "estado civil",
              "como conheceu", "indicacao", "encaminhado por"],
}

# campos que podem receber várias colunas
MULTIPLOS = {"endereco_parte", "extra"}

ROTULOS = {
    "nome": "Nome", "nascimento": "Nascimento", "cpf": "CPF", "sexo": "Sexo", "telefone": "Telefone",
    "email": "E-mail", "endereco": "Endereço completo", "endereco_parte": "Endereço (parte: rua, nº, bairro…)",
    "escolaridade": "Escolaridade", "profissao": "Profissão",
    "responsavel_nome": "Responsável", "responsavel_cpf": "CPF do responsável",
    "responsavel_telefone": "Telefone do responsável",
    "resp_fin_nome": "Responsável financeiro (nome)", "resp_fin_cpf": "Responsável financeiro (CPF)",
    "resp_fin_telefone": "Responsável financeiro (telefone)",
    "convenio": "Convênio", "valor_sessao": "Valor da sessão",
    "observacoes": "Observações", "abordagem": "Abordagem", "status": "Status (ativo/inativo)",
    "extra": "Guardar nas observações (com o título)",
}

def normalizar(texto):
    t = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()

class ErroImportacao(Exception):
    pass

def ler_planilha(nome_arquivo, conteudo):
    """Devolve (cabecalho, linhas) como listas de textos/valores."""
    nome = (nome_arquivo or "").lower()
    if nome.endswith(".xlsx") or nome.endswith(".xlsm"):
        try:
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(conteudo), read_only=True, data_only=True)
        except Exception:
            raise ErroImportacao("Não consegui abrir a planilha. Salve-a novamente como .xlsx ou .csv.")
        aba = next((w for w in wb.worksheets if normalizar(w.title) in ("pacientes", "paciente")), wb.worksheets[0])
        linhas = [list(r) for r in aba.iter_rows(values_only=True)]
    elif nome.endswith(".csv") or nome.endswith(".txt"):
        for cod in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                texto = conteudo.decode(cod)
                break
            except UnicodeDecodeError:
                continue
        try:
            dialeto = csv.Sniffer().sniff(texto[:5000], delimiters=";,\t")
        except csv.Error:
            dialeto = csv.excel
            dialeto.delimiter = ";" if texto.count(";") > texto.count(",") else ","
        linhas = list(csv.reader(io.StringIO(texto), dialeto))
    elif nome.endswith(".xls"):
        raise ErroImportacao("Arquivos .xls (Excel antigo) não são aceitos. Abra no Excel ou Google Planilhas "
                             "e salve como .xlsx ou .csv.")
    else:
        raise ErroImportacao("Envie um arquivo .xlsx (Excel) ou .csv.")
    linhas = [l for l in linhas if any(str(c).strip() for c in l if c is not None)]
    if len(linhas) < 2:
        raise ErroImportacao("A planilha precisa ter uma linha de títulos e pelo menos um paciente.")
    cab = [str(c).strip() if c is not None else "" for c in linhas[0]]
    return cab, linhas[1:]

def mapear_colunas(cabecalho):
    """Para cada coluna, o campo do sistema correspondente ('' = ignorar)."""
    usados = set()
    mapa = []
    for col in cabecalho:
        n = normalizar(col)
        achado = ""
        for campo, nomes in SINONIMOS.items():
            if (campo in MULTIPLOS or campo not in usados) and n in nomes:
                achado = campo
                break
        if not achado:  # correspondência parcial (ex.: "Telefone celular (WhatsApp)")
            for campo, nomes in SINONIMOS.items():
                if campo in MULTIPLOS or campo == "resp_fin_nome":
                    continue
                if campo not in usados and any(len(x) > 3 and x in n for x in nomes):
                    if "respons" in n and not campo.startswith("responsavel"):
                        continue
                    achado = campo
                    break
        if not achado and n:
            achado = "extra"  # coluna desconhecida: guarda nas observações para não perder nada
        if achado:
            usados.add(achado)
        mapa.append(achado)
    return mapa

def converter_data(v):
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, (int, float)) and 1000 < v < 80000:  # número de série do Excel
        return (date(1899, 12, 30) + timedelta(days=int(v))).isoformat()
    s = str(v).strip()
    for fmt in ("%d/%m/%Y", "%d/%m/%y", "%Y-%m-%d", "%d-%m-%Y", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            d = datetime.strptime(s, fmt).date()
            if d.year > date.today().year:  # 05/03/15 -> 2015, não 2115
                d = d.replace(year=d.year - 100)
            return d.isoformat()
        except ValueError:
            continue
    return None

def texto(v):
    if v is None:
        return None
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = str(v).strip()
    return s or None

SEXOS = {"m": "Masculino", "masc": "Masculino", "masculino": "Masculino", "f": "Feminino", "fem": "Feminino",
         "feminino": "Feminino"}
INATIVOS = {"inativo", "inativa", "alta", "encerrado", "encerrada", "arquivado", "arquivada", "desligado", "interrompido"}

def montar_pacientes(linhas, mapa, cabecalho=None):
    """Converte as linhas em dicionários prontos para gravar, com avisos por linha."""
    cabecalho = cabecalho or [""] * len(mapa)
    saida = []
    for i, linha in enumerate(linhas, start=2):
        p, avisos, partes_end, extras, fin, cep = {}, [], [], [], {}, None
        for valor, campo, titulo in zip(linha, mapa, cabecalho):
            if not campo or valor is None or str(valor).strip() == "":
                continue
            if campo == "nascimento":
                d = converter_data(valor)
                if d:
                    p[campo] = d
                else:
                    avisos.append(f"data de nascimento não reconhecida: {valor}")
            elif campo == "valor_sessao":
                n = valor if isinstance(valor, (int, float)) else numero(valor)
                if n is not None:
                    p[campo] = float(n)
            elif campo == "endereco_parte":
                if normalizar(titulo) == "cep":
                    cep = "CEP " + texto(valor)
                else:
                    partes_end.append(texto(valor))
            elif campo == "extra":
                extras.append(f"{titulo}: {texto(valor)}")
            elif campo.startswith("resp_fin_"):
                fin[campo[9:]] = texto(valor)
            elif campo == "status":
                if normalizar(valor) in INATIVOS:
                    p["ativo"] = 0
            elif campo == "sexo":
                p[campo] = SEXOS.get(normalizar(valor), texto(valor))
            elif campo == "observacoes" and campo in p:
                p[campo] += "\n" + texto(valor)
            else:
                p[campo] = texto(valor)
        if not p.get("nome"):
            continue  # linha sem nome é ignorada
        if "linha de exemplo" in normalizar(p.get("observacoes")):
            continue  # linha de exemplo dos modelos de planilha
        if partes_end or cep:
            p["endereco"] = ", ".join(([p["endereco"]] if p.get("endereco") else []) + partes_end + ([cep] if cep else []))
        # responsável financeiro: vira o "responsável" do cadastro se não houver responsável legal
        # e se for outra pessoa (ele aparece nos recibos); senão, fica registrado nas observações
        if fin.get("nome") and normalizar(fin["nome"]) != normalizar(p["nome"]):
            if not p.get("responsavel_nome"):
                p["responsavel_nome"] = fin["nome"]
                if fin.get("cpf"):
                    p["responsavel_cpf"] = fin["cpf"]
                if fin.get("telefone") and not p.get("responsavel_telefone"):
                    p["responsavel_telefone"] = fin["telefone"]
            else:
                extras.append("Responsável financeiro: " + " · ".join(v for v in (fin.get("nome"), fin.get("cpf"),
                                                                                   fin.get("telefone")) if v))
        if extras:
            p["observacoes"] = "\n".join(([p["observacoes"]] if p.get("observacoes") else []) + extras)
        saida.append({"linha": i, "dados": p, "avisos": avisos})
    return saida
