import re
from datetime import date, datetime

DIAS_SEMANA = ["segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado", "domingo"]
MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto",
         "setembro", "outubro", "novembro", "dezembro"]

def parse_data(s):
    if not s:
        return None
    try:
        return datetime.strptime(s[:10], "%Y-%m-%d").date()
    except ValueError:
        return None

def parse_dt(s):
    if not s:
        return None
    try:
        return datetime.strptime(s[:16], "%Y-%m-%dT%H:%M")
    except ValueError:
        return None

def data_br(s):
    d = parse_data(s) if isinstance(s, str) else s
    return d.strftime("%d/%m/%Y") if d else ""

def data_extenso(d):
    if isinstance(d, str):
        d = parse_data(d)
    if not d:
        return ""
    return f"{d.day} de {MESES[d.month - 1]} de {d.year}"

def idade(nascimento, ref=None):
    d = parse_data(nascimento)
    if not d:
        return None
    ref = ref or date.today()
    return ref.year - d.year - ((ref.month, ref.day) < (d.month, d.day))

def moeda(v):
    if v is None or v == "":
        return "R$ 0,00"
    s = f"{float(v):,.2f}"
    return "R$ " + s.replace(",", "X").replace(".", ",").replace("X", ".")

def numero(s):
    """Converte '1.234,56' ou '1234.56' para float."""
    if s is None:
        return None
    s = str(s).strip().replace("R$", "").strip()
    if not s:
        return None
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None

def telefone_whatsapp(tel):
    """Normaliza para o formato internacional usado pelo WhatsApp (somente dígitos)."""
    if not tel:
        return None
    d = re.sub(r"\D", "", tel)
    if d.startswith("0"):
        d = d.lstrip("0")
    if len(d) in (10, 11):
        d = "55" + d
    return d if len(d) >= 12 else None

# ---------- valor por extenso (para recibos) ----------
_UN = ["", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez", "onze", "doze",
       "treze", "quatorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove"]
_DZ = ["", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"]
_CT = ["", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos",
       "oitocentos", "novecentos"]

def _ate_999(n):
    if n == 0:
        return ""
    if n == 100:
        return "cem"
    partes = []
    c, r = divmod(n, 100)
    if c:
        partes.append(_CT[c])
    if r < 20:
        if r:
            partes.append(_UN[r])
    else:
        d, u = divmod(r, 10)
        partes.append(_DZ[d] + (f" e {_UN[u]}" if u else ""))
    return " e ".join(partes)

def _inteiro_extenso(n):
    if n == 0:
        return "zero"
    milhoes, resto = divmod(n, 1_000_000)
    milhares, unidades = divmod(resto, 1000)
    grupos = []
    if milhoes:
        grupos.append(_ate_999(milhoes) + (" milhão" if milhoes == 1 else " milhões"))
    if milhares:
        grupos.append("mil" if milhares == 1 else _ate_999(milhares) + " mil")
    if unidades:
        grupos.append(_ate_999(unidades))
    if len(grupos) > 1 and (unidades < 100 or unidades % 100 == 0) and unidades:
        return " ".join(grupos[:-1]) + " e " + grupos[-1]
    return " ".join(grupos)

def valor_extenso(v):
    v = round(float(v or 0), 2)
    reais = int(v)
    centavos = int(round((v - reais) * 100))
    partes = []
    if reais:
        txt = _inteiro_extenso(reais)
        if reais % 1_000_000 == 0:
            txt += " de"
        partes.append(txt + (" real" if reais == 1 else " reais"))
    if centavos:
        partes.append(_inteiro_extenso(centavos) + (" centavo" if centavos == 1 else " centavos"))
    return " e ".join(partes) if partes else "zero real"
