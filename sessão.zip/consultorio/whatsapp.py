"""Lembretes por WhatsApp.

Dois modos:
- manual: o sistema monta a mensagem e abre o WhatsApp (Web ou celular) já
  com o texto pronto; basta tocar em Enviar. Funciona sem nenhum cadastro.
- automatico: envia sozinho pela API oficial do WhatsApp (WhatsApp Cloud API
  da Meta), usando um modelo de mensagem aprovado. Veja o README.
"""
import urllib.parse
import requests

from util import parse_dt, DIAS_SEMANA, telefone_whatsapp

def campos_mensagem(atendimento, paciente, settings):
    dt = parse_dt(atendimento["inicio"])
    return {
        "nome": (paciente["nome"] or "").split(" ")[0],
        "nome_completo": paciente["nome"] or "",
        "data": dt.strftime("%d/%m") if dt else "",
        "dia_semana": DIAS_SEMANA[dt.weekday()] if dt else "",
        "hora": dt.strftime("%H:%M") if dt else "",
        "profissional": settings.get("profissional_nome", ""),
        "consultorio": settings.get("consultorio_nome", ""),
        "endereco": settings.get("consultorio_endereco", ""),
        "link": atendimento["link_online"] or "",
    }

def montar_mensagem(modelo, campos):
    texto = modelo or ""
    for k, v in campos.items():
        texto = texto.replace("{" + k + "}", str(v))
    return texto

def link_wa(telefone, texto):
    tel = telefone_whatsapp(telefone)
    if not tel:
        return None
    return f"https://wa.me/{tel}?text={urllib.parse.quote(texto)}"

def enviar_api(settings, telefone, campos):
    """Envia via WhatsApp Cloud API usando modelo aprovado.

    O modelo deve ter 3 variáveis no corpo, nesta ordem: {{1}} nome, {{2}} data, {{3}} hora.
    Retorna (ok: bool, detalhe: str).
    """
    token = settings.get("wa_token")
    phone_id = settings.get("wa_phone_id")
    modelo = settings.get("wa_template") or "lembrete_sessao"
    idioma = settings.get("wa_template_lang") or "pt_BR"
    tel = telefone_whatsapp(telefone)
    if not (token and phone_id):
        return False, "WhatsApp API não configurada (token e ID do número)."
    if not tel:
        return False, "Telefone inválido."
    corpo = {
        "messaging_product": "whatsapp",
        "to": tel,
        "type": "template",
        "template": {
            "name": modelo,
            "language": {"code": idioma},
            "components": [{
                "type": "body",
                "parameters": [
                    {"type": "text", "text": campos["nome"]},
                    {"type": "text", "text": f'{campos["dia_semana"]}, {campos["data"]}'},
                    {"type": "text", "text": campos["hora"]},
                ],
            }],
        },
    }
    try:
        r = requests.post(
            f"https://graph.facebook.com/v20.0/{phone_id}/messages",
            json=corpo,
            headers={"Authorization": f"Bearer {token}"},
            timeout=20,
        )
    except requests.RequestException as e:
        return False, f"Falha de conexão: {e}"
    if r.ok:
        return True, "Enviado"
    try:
        msg = r.json().get("error", {}).get("message", r.text)
    except ValueError:
        msg = r.text
    return False, f"Erro {r.status_code}: {msg}"
