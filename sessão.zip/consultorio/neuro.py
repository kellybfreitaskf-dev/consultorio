"""Conversão de escores e classificação para avaliação neuropsicológica.

O sistema NÃO contém tabelas normativas de testes (que são protegidas e
de uso restrito). A profissional informa o escore padronizado obtido no
manual do teste e o sistema converte para uma métrica comum (escore Z),
calcula o percentil aproximado e sugere a classificação.
"""
from statistics import NormalDist

_N = NormalDist()

TIPOS_ESCORE = [
    ("QI", "Escore padrão / QI (média 100, DP 15)"),
    ("escalar", "Ponderado / escalar (média 10, DP 3)"),
    ("T", "Escore T (média 50, DP 10)"),
    ("z", "Escore Z (média 0, DP 1)"),
    ("percentil", "Percentil"),
]

DOMINIOS = [
    "Eficiência intelectual",
    "Atenção",
    "Funções executivas",
    "Memória",
    "Linguagem",
    "Habilidades visuoespaciais / visuoconstrutivas",
    "Velocidade de processamento",
    "Funções motoras",
    "Cognição social",
    "Desempenho acadêmico",
    "Aspectos emocionais / comportamentais",
    "Outro",
]

# Apenas nomes, para sugestão de preenchimento
TESTES_SUGERIDOS = [
    "WISC-IV", "WISC-V", "WAIS-III", "WASI", "WPPSI-IV", "SON-R 2½-7", "Matrizes Progressivas de Raven",
    "BPA-2 (Bateria Psicológica para Avaliação da Atenção)", "Teste D2-R", "TAVIS-4", "CPT-II",
    "FDT (Teste dos Cinco Dígitos)", "Teste de Trilhas (TMT)", "Stroop", "Torre de Londres",
    "WCST (Wisconsin)", "Fluência Verbal (FAS / Categorias)", "RAVLT (Rey Auditory Verbal Learning Test)",
    "Figuras Complexas de Rey", "Span de Dígitos", "Cubos de Corsi", "Bateria NEUPSILIN", "NEUPSILIN-Inf",
    "TDE-II (Teste de Desempenho Escolar)", "PROLEC", "Teste de Nomeação de Boston", "Token Test",
    "Bender (B-SPG)", "Escala SNAP-IV", "ETDAH", "Vineland-3", "M-CHAT-R/F", "ADOS-2", "CARS-2",
    "BDI-II", "BAI", "EBADEP", "Escala de Estresse Infantil", "CBCL", "SDQ", "MoCA", "MEEM (Mini-Mental)",
]

def para_z(tipo, valor):
    if valor is None or tipo is None:
        return None
    v = float(valor)
    if tipo == "z":
        return v
    if tipo == "T":
        return (v - 50) / 10
    if tipo == "QI":
        return (v - 100) / 15
    if tipo == "escalar":
        return (v - 10) / 3
    if tipo == "percentil":
        p = min(max(v, 0.1), 99.9) / 100
        return _N.inv_cdf(p)
    return None

def percentil(z):
    if z is None:
        return None
    return round(_N.cdf(z) * 100, 1)

# Faixas em métrica de escore padrão (100/15), usuais em escalas Wechsler
FAIXAS = [
    (130, "Muito superior", "muito-superior"),
    (120, "Superior", "superior"),
    (110, "Média superior", "media-superior"),
    (90, "Média", "media"),
    (80, "Média inferior", "media-inferior"),
    (70, "Limítrofe", "limitrofe"),
    (-999, "Extremamente baixo", "extremamente-baixo"),
]

def classificar(z):
    if z is None:
        return ("—", "")
    qi = 100 + 15 * z
    for limite, rotulo, css in FAIXAS:
        if qi >= limite:
            return (rotulo, css)
    return ("—", "")

def analisar_teste(t):
    """Recebe uma linha da tabela testes e devolve um dict com os cálculos."""
    z = para_z(t["tipo_escore"], t["escore"]) if t["escore"] is not None else None
    z_funcional = -z if (z is not None and t["inverso"]) else z
    rotulo, css = classificar(z_funcional)
    return {
        "z": round(z, 2) if z is not None else None,
        "z_funcional": round(z_funcional, 2) if z_funcional is not None else None,
        "percentil": percentil(z),
        "classificacao": rotulo,
        "css": css,
    }
