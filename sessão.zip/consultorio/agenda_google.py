"""Integração com o Google Agenda.

- link "Adicionar ao Google Agenda" (funciona sem nenhuma configuração);
- arquivo .ics para importar vários atendimentos de uma vez;
- endereço de assinatura (feed .ics) que o Google Agenda atualiza sozinho
  quando o sistema está publicado na internet.
"""
import urllib.parse
from datetime import datetime, timedelta

from util import parse_dt

FUSO = "America/Sao_Paulo"

def titulo_evento(nome, formato):
    partes = (nome or "").split()
    if not partes:
        return "Atendimento"
    if formato == "completo":
        return nome
    if formato == "iniciais":
        return "".join(p[0].upper() + "." for p in partes if len(p) > 2 or p[0].isupper())
    # padrão: primeiro nome + inicial do último sobrenome
    return partes[0] + (f" {partes[-1][0].upper()}." if len(partes) > 1 else "")

def _fmt(dt):
    return dt.strftime("%Y%m%dT%H%M%S")

def link_google(titulo, inicio, duracao_min, detalhes="", local="", repetir=None, intervalo_dias=7):
    """Link que abre o Google Agenda com o evento preenchido.
    repetir = quantidade de ocorrências da série (None = sessão única)."""
    ini = parse_dt(inicio)
    fim = ini + timedelta(minutes=duracao_min or 50)
    params = {"action": "TEMPLATE", "text": titulo, "dates": f"{_fmt(ini)}/{_fmt(fim)}", "ctz": FUSO,
              "details": detalhes, "location": local}
    if repetir and repetir > 1:
        if intervalo_dias % 7 == 0:
            params["recur"] = f"RRULE:FREQ=WEEKLY;INTERVAL={intervalo_dias // 7};COUNT={repetir}"
        else:
            params["recur"] = f"RRULE:FREQ=DAILY;INTERVAL={intervalo_dias};COUNT={repetir}"
    return "https://calendar.google.com/calendar/render?" + urllib.parse.urlencode(
        {k: v for k, v in params.items() if v}, quote_via=urllib.parse.quote)

def _esc(t):
    return (t or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")

def _dobrar(linha):
    """Linhas de no máximo 75 bytes, como manda o formato iCalendar."""
    b = linha.encode("utf-8")
    if len(b) <= 75:
        return linha
    partes, atual = [], ""
    for ch in linha:
        if len((atual + ch).encode("utf-8")) > (75 if not partes else 74):
            partes.append(atual)
            atual = ch
        else:
            atual += ch
    partes.append(atual)
    return "\r\n ".join(partes)

def gerar_ics(eventos, nome_agenda="Consultório"):
    """eventos: dicts com uid, titulo, inicio ('YYYY-MM-DDTHH:MM'), duracao_min, descricao, local, cancelado."""
    agora = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Consultorio//PT-BR", "CALSCALE:GREGORIAN",
         "METHOD:PUBLISH", f"X-WR-CALNAME:{_esc(nome_agenda)}", f"X-WR-TIMEZONE:{FUSO}",
         "BEGIN:VTIMEZONE", f"TZID:{FUSO}", "BEGIN:STANDARD", "DTSTART:19700101T000000",
         "TZOFFSETFROM:-0300", "TZOFFSETTO:-0300", "TZNAME:-03", "END:STANDARD", "END:VTIMEZONE"]
    for e in eventos:
        ini = parse_dt(e["inicio"])
        if not ini:
            continue
        fim = ini + timedelta(minutes=e.get("duracao_min") or 50)
        L += ["BEGIN:VEVENT", f"UID:{e['uid']}", f"DTSTAMP:{agora}",
              f"DTSTART;TZID={FUSO}:{_fmt(ini)}", f"DTEND;TZID={FUSO}:{_fmt(fim)}",
              f"SUMMARY:{_esc(e['titulo'])}"]
        if e.get("descricao"):
            L.append(f"DESCRIPTION:{_esc(e['descricao'])}")
        if e.get("local"):
            L.append(f"LOCATION:{_esc(e['local'])}")
        L.append("STATUS:CANCELLED" if e.get("cancelado") else "STATUS:CONFIRMED")
        L.append("END:VEVENT")
    L.append("END:VCALENDAR")
    return "\r\n".join(_dobrar(l) for l in L) + "\r\n"
