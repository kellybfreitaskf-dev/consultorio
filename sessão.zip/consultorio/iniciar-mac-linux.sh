#!/bin/bash
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "Instale o Python em https://www.python.org/downloads/"; exit 1; }
if [ ! -d .venv ]; then
  echo "Preparando o sistema pela primeira vez, aguarde..."
  python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt
fi
( sleep 2; open http://localhost:5000 2>/dev/null || xdg-open http://localhost:5000 ) &
.venv/bin/python app.py
