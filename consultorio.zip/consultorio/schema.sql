CREATE TABLE IF NOT EXISTS settings (
    chave TEXT PRIMARY KEY,
    valor TEXT
);

CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    senha_hash TEXT NOT NULL,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pacientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    nascimento TEXT,
    cpf TEXT,
    sexo TEXT,
    telefone TEXT,
    email TEXT,
    endereco TEXT,
    escolaridade TEXT,
    profissao TEXT,
    responsavel_nome TEXT,
    responsavel_cpf TEXT,
    responsavel_telefone TEXT,
    convenio TEXT,
    valor_sessao REAL,
    observacoes TEXT,
    ativo INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS atendimentos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    paciente_id INTEGER NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    inicio TEXT NOT NULL,           -- 'YYYY-MM-DDTHH:MM' horário local
    duracao_min INTEGER DEFAULT 50,
    tipo TEXT,
    modalidade TEXT DEFAULT 'Presencial',
    link_online TEXT,
    status TEXT DEFAULT 'agendado',
    valor REAL,
    observacoes TEXT,
    serie_id TEXT,
    lembrete_enviado_em TEXT,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_atend_inicio ON atendimentos(inicio);
CREATE INDEX IF NOT EXISTS idx_atend_paciente ON atendimentos(paciente_id);

CREATE TABLE IF NOT EXISTS evolucoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    paciente_id INTEGER NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    atendimento_id INTEGER REFERENCES atendimentos(id) ON DELETE SET NULL,
    data TEXT NOT NULL,
    texto TEXT NOT NULL,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TEXT
);

CREATE TABLE IF NOT EXISTS anamneses (
    paciente_id INTEGER PRIMARY KEY REFERENCES pacientes(id) ON DELETE CASCADE,
    queixa TEXT,
    historico TEXT,
    desenvolvimento TEXT,
    saude TEXT,
    medicacoes TEXT,
    familia TEXT,
    escolar TEXT,
    social TEXT,
    outros TEXT,
    atualizado_em TEXT
);

CREATE TABLE IF NOT EXISTS avaliacoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    paciente_id INTEGER NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    titulo TEXT NOT NULL,
    data_inicio TEXT,
    data_fim TEXT,
    solicitante TEXT,
    motivo TEXT,
    hipoteses TEXT,
    status TEXT DEFAULT 'Em andamento',
    conclusao TEXT,
    recomendacoes TEXT,
    laudo TEXT,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS testes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    avaliacao_id INTEGER NOT NULL REFERENCES avaliacoes(id) ON DELETE CASCADE,
    nome TEXT NOT NULL,
    subteste TEXT,
    dominio TEXT,
    data TEXT,
    escore_bruto TEXT,
    tipo_escore TEXT,
    escore REAL,
    inverso INTEGER DEFAULT 0,
    observacoes TEXT
);

CREATE TABLE IF NOT EXISTS lancamentos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo TEXT NOT NULL,              -- 'receita' ou 'despesa'
    descricao TEXT NOT NULL,
    categoria TEXT,
    valor REAL NOT NULL,
    vencimento TEXT NOT NULL,
    pagamento TEXT,                  -- data em que foi pago (NULL = pendente)
    forma_pagamento TEXT,
    paciente_id INTEGER REFERENCES pacientes(id) ON DELETE SET NULL,
    atendimento_id INTEGER REFERENCES atendimentos(id) ON DELETE SET NULL,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_lanc_venc ON lancamentos(vencimento);

CREATE TABLE IF NOT EXISTS sessoes_ia (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    atendimento_id INTEGER REFERENCES atendimentos(id) ON DELETE CASCADE,
    paciente_id INTEGER NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
    status TEXT NOT NULL,            -- transcrevendo | analisando | pronto | erro
    origem TEXT,                     -- gravacao | arquivo | texto
    observacao TEXT,                 -- nota da psicóloga enviada junto
    transcricao TEXT,
    evolucao TEXT,
    analise_caso TEXT,
    feedback_atuacao TEXT,
    proxima_sessao TEXT,
    alerta_risco INTEGER DEFAULT 0,
    resumo_alerta TEXT,
    abordagem TEXT,
    erro TEXT,
    tokens_entrada INTEGER,
    tokens_saida INTEGER,
    criado_em TEXT,
    concluido_em TEXT
);
CREATE INDEX IF NOT EXISTS idx_ia_atend ON sessoes_ia(atendimento_id);
